"""
reference
=========

Utility functions for comparing CubeFit’s Kaczmarz solution to a reference
SciPy NNLS solution, primarily for debugging and quality‑control.
"""

from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import nnls

from CubeFit.model_cube import ModelCube


def compare_fit_reference(
    z,
    aperture: int,
    tem_pix,
    obs_pix,
    show_residual: bool = True,
) -> None:
    """
    Plot observed spectrum, reference NNLS model, and residual.

    Parameters
    ----------
    z            : zarr.hierarchy.Group
        Zarr group opened by ``ZarrManager``.
    aperture     : int
        Spatial aperture index.
    tem_pix      : ndarray
        Template wavelength centres passed to ``ModelCube``.
    obs_pix      : ndarray
        Observed wavelength centres passed to ``ModelCube``.
    show_residual: bool, default=True
        If True, display residual panel beneath fit.
    """
    y = z["Data"][aperture]
    A = ModelCube(
        z["Templates"][:],
        z["LOSVD"][aperture],
        tem_pix,
        obs_pix,
    ).convolve()
    x_ref, _ = nnls(A, y)
    y_ref = A @ x_ref
    resid = y - y_ref

    if show_residual:
        fig, (ax0, ax1) = plt.subplots(
            2, 1, figsize=(10, 6), sharex=True,
            gridspec_kw={"height_ratios": [2, 1]},
        )
    else:
        fig, ax0 = plt.subplots(figsize=(10, 4))

    ax0.plot(y, label="Observed", alpha=0.7)
    ax0.plot(y_ref, label="Reference NNLS", alpha=0.7)
    ax0.set_title(f"Aperture {aperture} — NNLS reference fit")
    ax0.set_ylabel("Flux")
    ax0.legend()

    if show_residual:
        ax1.plot(resid, color="gray")
        ax1.set_ylabel("Residual")
        ax1.set_xlabel("Pixel")

    plt.tight_layout()
    plt.show()
