# -*- coding: utf-8 -*-
r"""
    model_cube.py
    Adriano Poci
    University of Oxford
    2025

    Platforms
    ---------
    Unix, Windows

    Synopsis
    --------
    Defines ModelCube: construction and convolution of template matrices with
    LOSVD kernels, including velocity derivatives and continuum expansions.
    Ensures correct order: convolution before rebinning, safe edge handling.

    Authors
    -------
    Adriano Poci <adriano.poci@physics.ox.ac.uk>

History
-------
v1.0:   Initial design for convolution/rebin. 2025
v1.1:   Handles full template grids, edge-safe, velocity shift support. 2025
v1.2:   Enhanced efficiency and parallelism for large cubes. 2025
"""

from __future__ import annotations
import numpy as np
import pathlib as plp
from scipy.signal import correlate, correlation_lags
from scipy.interpolate import interp1d
import matplotlib.pyplot as plt

try:
    # pyFFTW ≥ 0.13 – provides a SciPy-style fftconvolve
    from pyfftw.interfaces.scipy_fft import fftconvolve as _fftw_conv
    fftconvolve = _fftw_conv
    _FFT_BACKEND = "pyFFTW"
except ImportError: # fall back to SciPy
    from scipy.signal import fftconvolve
    _FFT_BACKEND = "scipy"

from CubeFit.logger import get_logger

curdir = plp.Path(__file__).parent
logger = get_logger()

class ModelCube:
    """
    Build model matrix A for one spatial aperture.

    Parameters
    ----------
    templates_flat : ndarray, (nPop, nPix_tem)
        Flattened template spectra (pixels first axis removed).
    losvd          : ndarray, (nVel, nComp)
        LOSVD kernels for this aperture.
    tem_pix        : ndarray, (nPix_tem,)
        Pixel centres of `templates_flat`.
    obs_pix        : ndarray, (nPix_obs,)
        Pixel centres of observed data.  Rebinning is performed from
        `tem_pix` to `obs_pix` unless ``skip_rebin`` is True _or_
        the two arrays are identical.
    skip_rebin     : bool, default False
        If True, assume templates are already on the obs grid; only
        convolution is applied.
    """

    def __init__(
        self,
        templates_fft: np.ndarray,
        rebin_matrix: np.ndarray | None,
        losvd: np.ndarray,
        tem_pix: np.ndarray,
        obs_pix: np.ndarray,
    ) -> None:
        self.templates_fft = templates_fft
        self.rebin_matrix = rebin_matrix
        if rebin_matrix is None:
            # If no rebinning matrix, assume obs_pix == tem_pix
            self.rebin_matrix = ModelCube.compute_rebin_matrix(tem_pix, obs_pix)
        self.losvd = losvd
        self.tem_pix = tem_pix
        self.obs_pix = obs_pix

        self.nPop, self.fft_size = self.templates_fft.shape
        self.nVel, self.nComp = losvd.shape
        self.nLSpec = obs_pix.size
        self.nTSpec = tem_pix.size

    # --------------------------------------------------------------------------

    @staticmethod
    def rebin_flux_conserving(spectra, old_c, new_c):
        """
        Flux‑conserving rebin — vectorised (no Python loops).
        spectra : (n_old, n_spec)
        Returns : (n_new, n_spec)
        """
        n_old, n_spec = spectra.shape
        n_new = new_c.size

        # bin edges
        old_e = np.concatenate([
            [old_c[0] - 0.5*(old_c[1]-old_c[0])],
            0.5*(old_c[1:] + old_c[:-1]),
            [old_c[-1] + 0.5*(old_c[-1]-old_c[-2])]
        ])
        new_e = np.concatenate([
            [new_c[0] - 0.5*(new_c[1]-new_c[0])],
            0.5*(new_c[1:] + new_c[:-1]),
            [new_c[-1] + 0.5*(new_c[-1]-new_c[-2])]
        ])

        # overlap matrix  (n_new, n_old)
        lo = np.maximum.outer(new_e[:-1], old_e[:-1])
        hi = np.minimum.outer(new_e[1:],  old_e[1:])
        overlap = np.clip(hi - lo, 0.0, None)
        weights = overlap / np.diff(old_e)  # broadcast div  (n_new,n_old)

        return weights @ spectra # (n_new,n_spec)

    # --------------------------------------------------------------------------

    @staticmethod
    def compute_rebin_matrix(old_c, new_c):
        """
        Compute rebinning matrix once and cache for efficiency.
        """
        old_e = np.concatenate([
            [old_c[0] - 0.5*(old_c[1]-old_c[0])],
            0.5*(old_c[1:] + old_c[:-1]),
            [old_c[-1] + 0.5*(old_c[-1]-old_c[-2])]
        ])
        new_e = np.concatenate([
            [new_c[0] - 0.5*(new_c[1]-new_c[0])],
            0.5*(new_c[1:] + new_c[:-1]),
            [new_c[-1] + 0.5*(new_c[-1]-new_c[-2])]
        ])
        lo = np.maximum.outer(new_e[:-1], old_e[:-1])
        hi = np.minimum.outer(new_e[1:],  old_e[1:])
        overlap = np.clip(hi - lo, 0.0, None)
        weights = overlap / np.diff(old_e)
        return weights

    # --------------------------------------------------------------------------

    def convolve(self):
        losvd_fft = np.fft.fft(self.losvd.T, n=self.fft_size, axis=1)
        product_fft = self.templates_fft[:, np.newaxis, :] *\
            losvd_fft[np.newaxis, :, :]
        convolved_full = np.fft.ifft(product_fft, axis=2).real

        start_idx = (self.nVel - 1) // 2
        end_idx = start_idx + self.nTSpec
        convolved = convolved_full[:, :, start_idx:end_idx]

        # Efficient matmul rebinning
        convolved_t = np.transpose(convolved, (0, 2, 1))
        rebinned = np.matmul(self.rebin_matrix, convolved_t)
        convolved_rebinned = np.transpose(rebinned, (1, 2, 0))

        return convolved_rebinned # shape: (nLSpec, nComp, nPop)

    # --------------------------------------------------------------------------

    @staticmethod
    def test_convolution_pixel_offset(
        template, kernel, tem_pix, obs_pix,
        plot=True,
        plot_dir=None,
        tag=""
    ):
        """
        Test for systematic pixel offset from convolution+rebinning.

        Parameters
        ----------
        template : 1D array (nTSpec)
            The input template (buffered grid).
        kernel   : 1D array (nVel or similar)
            LOSVD or kernel to convolve with.
        tem_pix  : 1D array
            Template grid (wavelength or pixel centers).
        obs_pix  : 1D array
            Observed grid (wavelength or pixel centers).
        plot : bool
            If True, save plots to plot_dir if provided, else show.
        plot_dir : str or None
            Directory to save plots. If None and plot=True, will use current dir.
        tag : str
            Optional extra label for the file names.

        Returns
        -------
        offset_pixels : float
            Measured offset (in obs_pix units) between rebin+convolve and direct.
        """

        # 1. Direct (unconvolved) rebin as reference
        interp_func = interp1d(tem_pix, template, kind='linear',
            bounds_error=False, fill_value=0.0)
        direct = interp_func(obs_pix)

        # 2. Convolve, then rebin
        conv = fftconvolve(template, kernel, mode='same')
        rebinned = ModelCube.rebin_flux_conserving(conv[:, None], tem_pix, obs_pix)[:, 0]
        direct_norm = direct / np.sum(direct)
        rebinned_norm = rebinned / np.sum(rebinned)

        # 3. Cross-correlate for offset
        corr = correlate(rebinned, direct, mode='full')
        lags = correlation_lags(len(rebinned), len(direct), mode='full')
        i_max = np.argmax(corr)
        if 0 < i_max < len(corr) - 1:
            x = lags[i_max-1:i_max+2]
            y = corr[i_max-1:i_max+2]
            fit = np.polyfit(x, y, 2)
            vertex = -fit[1]/(2*fit[0])
            offset = vertex
        else:
            offset = lags[i_max]

        if plot:
            if plot_dir is None:
                plot_dir = plp.Path(curdir)
            plot_dir.mkdir(exist_ok=True)
            fname1 = plot_dir/f"conv_offset_{tag}_spectra.png"
            fname2 = plot_dir/f"conv_offset_{tag}_xcorr.png"

            plt.figure(figsize=(8, 4))
            plt.plot(obs_pix, direct_norm, label='Direct interp (no conv)')
            plt.plot(obs_pix, rebinned_norm, label='Conv + Rebin', ls='--')
            plt.legend()
            plt.title(f"Measured offset: {offset:.2f} pixels")
            plt.xlabel('Wavelength or pixel')
            plt.ylabel('Flux')
            plt.tight_layout()
            plt.savefig(fname1, dpi=150)
            plt.close()

            plt.figure()
            plt.plot(lags, corr)
            plt.axvline(offset, color='r', ls='--')
            plt.title('Cross-correlation')
            plt.xlabel('Lag (pixels)')
            plt.ylabel('Correlation')
            plt.tight_layout()
            plt.savefig(fname2, dpi=150)
            plt.close()
            logger.log(f"[CubeFit] Convolution offset diagnostics saved to:\n {fname1}\n {fname2}")

        return offset

# ------------------------------------------------------------------------------
