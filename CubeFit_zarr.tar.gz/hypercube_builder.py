# -*- coding: utf-8 -*-
r"""
    hypercube_builder.py
    Adriano Poci
    University of Oxford
    2025

    Platforms
    ---------
    Unix, Windows

    Synopsis
    --------
    Manages Zarr data storage for CubeFit pipeline, including creation, loading,
    and validation of large, chunked arrays (templates, data cube, LOSVD, weights).
    Supports buffered template grids for safe convolution.

    Authors
    -------
    Adriano Poci <adriano.poci@physics.ox.ac.uk>

History
-------
v1.0:   Initial design and validation. 14 August 2025
v1.1:   Added Zarr v3 sharding support and safe-direct writes. 5 September 2025

hypercube_builder.py
Direct, shard-based HyperCube builder with an external v3 models store.

Why this design works:
- We leave your original store (v2 or v3) alone for inputs (LOSVD/DataCube).
- We write /models into a separate, dedicated **v3 store** using ShardingCodec.
- No more "codecs= not accepted" issues: we never call v2 Group.create_array.
- Disk dtype is float32; compute stays float64 inside the solver.

Outputs:
- <base>/HyperCube.attrs has a manifest with:
    { "models_store": "<absolute path to v3 models store>", ... }

Reader change (2 lines) is shown below so it follows this pointer if needed.
"""

from __future__ import annotations

from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass
from hashlib import blake2b
from datetime import datetime, timezone
from typing import Iterator, Tuple, Optional
import json

import numpy as np
import zarr
from zarr.codecs import ShardingCodec
from tqdm import tqdm

# -----------------------------------------------------------------------------
# Logger
# -----------------------------------------------------------------------------
try:
    from CubeFit.logger import get_logger  # type: ignore
    logger = get_logger()
except Exception:  # pragma: no cover
    class _Logger:
        def log(self, *msg): print(*msg)
        from contextlib import contextmanager
        @contextmanager
        def capture_all_output(self): yield
    logger = _Logger()

# -----------------------------------------------------------------------------
# Config
# -----------------------------------------------------------------------------
DEFAULT_MODELS_DIRNAME = "HyperCube_models.v3"   # created next to base store

def _canon(p: str | Path) -> str:
    try:
        return str(Path(p).resolve())
    except Exception:
        return str(Path(p).absolute())

@dataclass(frozen=True)
class ShardPlan:
    shape: Tuple[int, int, int, int]
    chunks: Tuple[int, int, int, int]
    shard: Tuple[int, int, int, int]
    tiles: list[Tuple[int, int, int, int, int, int]]  # (s0,s1,c0,c1,p0,p1)

# -----------------------------------------------------------------------------
# Flexible open for the base store (read LOSVD/DataCube/etc.)
# -----------------------------------------------------------------------------
def _open_base(path: Path):
    """
    Open an existing store (v3 preferred). If v3 open fails, fall back to v2.
    We never pass `codecs=` here; we only read small inputs from base.
    """
    p = str(path)
    try:
        return zarr.group(store=p, zarr_format=3)   # v3
    except Exception:
        return zarr.open_group(p, mode="a")         # v2 (create if missing)

# -----------------------------------------------------------------------------
# Always-v3 models store (separate directory)
# -----------------------------------------------------------------------------
def _open_models_v3(models_path: Path) -> zarr.Group:
    """
    Create/open the dedicated v3 models store. Ensures the directory exists
    before calling the v3 API. Falls back to an explicit DirectoryStore if
    the plain path call trips FileNotFoundError on your zarr build.
    """
    models_path = Path(models_path).resolve()
    models_path.mkdir(parents=True, exist_ok=True)

    try:
        g = zarr.group(store=str(models_path), zarr_format=3)
        logger.log(f"[HyperCube] Opened v3 models store at {models_path}")
        return g
    except FileNotFoundError:
        # Some builds require an explicit store object.
        try:
            from zarr.storage import DirectoryStore  # v2/v3-compatible mapping
        except Exception:
            # Fallback import name on some builds
            from zarr.storage import FSStore as DirectoryStore  # type: ignore
        store = DirectoryStore(str(models_path))
        g = zarr.group(store=store, zarr_format=3)
        logger.log(f"[HyperCube] Opened v3 models store via DirectoryStore at {models_path}")
        return g

def _ensure_models_array(
    models_root,
    *,
    shape: tuple[int, int, int, int],
    chunks: tuple[int, int, int, int],  # small inner chunk (S,C,P,L)
    shard: tuple[int, int, int, int],   # big super-chunk  (sS,sC,sP,L)
):
    import inspect
    # Reuse if compatible (accept both sharded and non-sharded when shapes match)
    if "models" in models_root:
        arr = models_root["models"]
        ok_shape  = tuple(arr.shape)  == shape
        ok_chunks = tuple(arr.chunks) == shard  # array chunks must match SUPER-chunk
        ok_dtype  = str(arr.dtype)    == "float32"
        if ok_shape and ok_chunks and ok_dtype:
            return arr
        del models_root["models"]

    # Try true v3 sharded creation
    supports_codecs = "codecs" in str(inspect.signature(models_root.create_array))
    if supports_codecs:
        sharding_cfg = {
            "name": "sharding",
            "configuration": {
                "chunk_shape": list(chunks),  # inner-chunk <= array chunks
                "codecs": []                  # simplest pipeline
            },
        }
        try:
            arr = models_root.create_array(
                "models",
                shape=shape,
                chunks=shard,       # BIG array chunk == super-chunk/file
                dtype="f4",
                codecs=(sharding_cfg,),
            )
            logger.log(
                f"[HyperCube] v3 sharded models created: shape={shape}, "
                f"chunks={shard} (super-chunk), inner={chunks}, dtype=float32"
            )
            return arr
        except Exception as e:
            logger.log(f"[HyperCube] Sharded creation failed: {type(e).__name__}: {e}; "
                       "falling back to non-sharded.")

    # Fallback: non-sharded (still works, just more files)
    arr = models_root.create_array(
        "models", shape=shape, chunks=chunks, dtype="f4"
    )
    logger.log(
        f"[HyperCube] models created (non-sharded): shape={shape}, "
        f"chunks={chunks}, dtype=float32"
    )
    return arr

# -----------------------------------------------------------------------------
# Manifest
# -----------------------------------------------------------------------------
def _manifest_core(shape, chunks, shard, dtype_models) -> dict:
    return {
        "schema": 10,
        "shape": tuple(map(int, shape)),
        "chunks": tuple(map(int, chunks)),
        "shard_shape": tuple(map(int, shard)),
        "dtype_models": dtype_models,      # 'f4'
    }

def _with_digest(core: dict) -> dict:
    h = blake2b(digest_size=20)
    h.update(json.dumps(core, sort_keys=True).encode())
    return {
        **core,
        "digest": h.hexdigest(),
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "env": {"numpy": np.__version__, "zarr": zarr.__version__},
    }

def _man_equal(a: dict, b: dict) -> bool:
    aa, bb = dict(a), dict(b)
    for k in ("generated_at", "env"):
        aa.pop(k, None); bb.pop(k, None)
    return json.dumps(aa, sort_keys=True) == json.dumps(bb, sort_keys=True)

# -----------------------------------------------------------------------------
# Tiling and planning
# -----------------------------------------------------------------------------
def _tiles(n: int, step: int) -> Iterator[Tuple[int, int]]:
    i = 0
    while i < n:
        j = min(i + step, n)
        yield i, j
        i = j

def _make_plan(nSpat, nComp, nPop, nLSpec, S, C, P, shard_S, shard_C, shard_P) -> ShardPlan:
    shape = (int(nSpat), int(nComp), int(nPop), int(nLSpec))
    chunks = (min(S, nSpat), min(C, nComp), min(P, nPop), nLSpec)
    sS = max(chunks[0], min(int(shard_S), nSpat))
    sC = max(chunks[1], min(int(shard_C), nComp))
    sP = max(chunks[2], min(int(shard_P), nPop))
    shard = (sS, sC, sP, nLSpec)

    tiles = [
        (s0, s1, c0, c1, p0, p1)
        for (s0, s1) in _tiles(nSpat, sS)
        for (c0, c1) in _tiles(nComp, sC)
        for (p0, p1) in _tiles(nPop,  sP)
    ]
    return ShardPlan(shape, chunks, shard, tiles)

# -----------------------------------------------------------------------------
# Worker globals (set by initializer)
# -----------------------------------------------------------------------------
G_BASE_PATH: Optional[Path] = None
G_MODELS_PATH: Optional[Path] = None
G_R_T: Optional[np.ndarray] = None         # (N_tspec, nLSpec)
G_TFFT_R: Optional[np.ndarray] = None      # (nPop, N_tspec)
G_LOSVD = None                             # base["LOSVD"]
G_TILE_CHUNKS: Optional[Tuple[int, int, int]] = None

# -----------------------------------------------------------------------------
# Convolution (module-level for pickling)
# -----------------------------------------------------------------------------
def _convolve_tile(
    s0: int, s1: int, c0: int, c1: int, p0: int, p1: int
) -> np.ndarray:
    """
    LOSVD ⊗ templates (FFT-based).
    Returns time-domain (S, C, P, N) float64 (C-contiguous).
    """
    T_sel = np.asarray(G_TFFT_R[p0:p1, :], order="C")
    N = int(T_sel.shape[1])

    W = np.asarray(G_LOSVD[s0:s1, :, c0:c1], order="C")   # (S,V,C)

    eps = 1e-32
    sums = W.sum(axis=1, keepdims=True)
    den = np.where(sums > eps, sums, 1.0)
    Wn = W / den
    zero_mask = (sums <= eps).squeeze(1)
    if zero_mask.any():
        v_center = Wn.shape[1] // 2
        si, ci = np.where(zero_mask)
        Wn[si, v_center, ci] = 1.0

    K_fft = np.fft.fft(np.fft.ifftshift(Wn, axes=1), n=N, axis=1)
    K_fft = np.swapaxes(K_fft, 1, 2)                   # (S,C,N)
    conv_fft = K_fft[:, :, None, :] * T_sel[None, None, :, :]
    td = np.fft.ifft(conv_fft, axis=3).real.astype(np.float64, copy=False)
    if not td.flags["C_CONTIGUOUS"]:
        td = np.ascontiguousarray(td)
    return td

# -----------------------------------------------------------------------------
# Worker init and fill
# -----------------------------------------------------------------------------
def _init_worker(
    base_path: str | Path,
    models_path: str | Path,
    R_T: np.ndarray,
    templates_fft: np.ndarray,
    tem_pix,
    obs_pix,
    tile_chunks: Tuple[int, int, int],
):
    """
    Per-process setup:
      - open base store (v3 or v2) to read LOSVD
      - open models store (v3) to write /models
      - resample templates_fft to target N = rows of R_T
    """
    global G_BASE_PATH, G_MODELS_PATH, G_R_T, G_TFFT_R, G_LOSVD, G_TILE_CHUNKS
    G_BASE_PATH = Path(base_path)
    G_MODELS_PATH = Path(models_path)
    G_R_T = np.asarray(R_T, dtype=np.float64, order="C")
    G_TILE_CHUNKS = tuple(int(x) for x in tile_chunks)

    # resample templates FFT once per worker
    T_fft = np.asarray(templates_fft, order="C")
    if not np.iscomplexobj(T_fft):
        T_fft = T_fft.astype(np.complex128, copy=False)
    N_src = int(T_fft.shape[1])
    N_tgt = int(G_R_T.shape[0])
    if N_src == N_tgt:
        G_TFFT_R = T_fft
    else:
        T_td = np.fft.ifft(T_fft, axis=1)
        G_TFFT_R = np.fft.fft(T_td, n=N_tgt, axis=1).astype(np.complex128, copy=False)

    # open base for LOSVD
    base = _open_base(G_BASE_PATH)
    if "LOSVD" not in base:
        raise RuntimeError("Missing 'LOSVD' in base store.")
    G_LOSVD = base["LOSVD"]
    if G_LOSVD.ndim != 3:
        raise RuntimeError(f"LOSVD must be 3-D, got {G_LOSVD.shape}.")

    # sanity open for models v3 store
    zarr.group(store=str(G_MODELS_PATH), zarr_format=3)

def _worker_fill_shard(sel):
    """
    Compute a shard (s0:s1, c0:c1, p0:p1) by iterating over small (S,C,P)
    compute tiles so peak memory stays bounded. Writes float32 tiles to disk.
    """
    if G_TILE_CHUNKS is None:
        raise RuntimeError("G_TILE_CHUNKS not initialized in worker.")
    s0, s1, c0, c1, p0, p1 = sel
    tS, tC, tP = G_TILE_CHUNKS  # compute tile sizes, e.g. (16, 1, 128)
    N = int(G_R_T.shape[0])

    # open models store (v3 or fallback) once per call
    mroot = zarr.group(store=str(G_MODELS_PATH), zarr_format=3)
    marr = mroot["models"]

    # iterate over small tiles within this shard using module-level _tiles()
    for ss0, ss1 in _tiles(s1 - s0, tS):
        a0, a1 = s0 + ss0, s0 + ss1
        for cc0, cc1 in _tiles(c1 - c0, tC):
            b0, b1 = c0 + cc0, c0 + cc1
            for pp0, pp1 in _tiles(p1 - p0, tP):
                c0p, c1p = p0 + pp0, p0 + pp1

                # 1) convolution on a small tile -> (ΔS,ΔC,ΔP,N) float64
                td = _convolve_tile(a0, a1, b0, b1, c0p, c1p)

                # 2) rebin to obs grid: (ΔS*ΔC*ΔP,N) @ (N,L) -> (ΔS,ΔC,ΔP,L)
                M = td.shape[0] * td.shape[1] * td.shape[2]
                out = td.reshape(M, N) @ G_R_T
                out = out.reshape(a1 - a0, b1 - b0, c1p - c0p, -1)

                # 3) cast to f32 and write
                if out.dtype != np.float32:
                    out = out.astype(np.float32, copy=False)
                marr[a0:a1, b0:b1, c0p:c1p, :] = out

    return 1

# -----------------------------------------------------------------------------
# Public API
# -----------------------------------------------------------------------------
def build_hypercube(
    zarr_path: str | Path,
    *,
    nSpat: int,
    nComp: int,
    nPop: int,
    nLSpec: int,
    # compute tiles (also used for array chunks)
    S: int = 16,
    C: int = 1,
    P: int = 256,
    # shard (big-file) extents
    shard_S: int = 128,
    shard_C: int = 23,
    shard_P: int = 128,
    templates_fft,
    rebin_matrix,
    tem_pix,
    obs_pix,
    n_workers: int,
    mode: str = "direct",
    check: str = "auto",            # "auto" | "force"
    models_dirname: str = DEFAULT_MODELS_DIRNAME,
    extra_manifest: dict | None = None,
) -> None:
    """
    Build or reuse the HyperCube models using a dedicated v3 models store.

    - Base store at `zarr_path` can be v2 or v3.
    - Models are stored at `<zarr_path>/<models_dirname>` (always v3).
    - Manifest pointer is saved at `<zarr_path>/HyperCube.attrs["models_store"]`.
    """
    if mode != "direct":
        logger.log("[HyperCube] Only 'direct' mode is supported.")

    base_path = Path(zarr_path)
    models_path = base_path / models_dirname

    # Open base (v3 preferred, else v2) to validate LOSVD and sizes
    base = _open_base(base_path)
    if "LOSVD" not in base:
        raise RuntimeError("Base store missing 'LOSVD'.")
    losvd = base["LOSVD"]
    if losvd.ndim != 3:
        raise RuntimeError(f"'LOSVD' must be 3-D, got {losvd.shape}.")
    if int(losvd.shape[0]) != int(nSpat) or int(losvd.shape[2]) != int(nComp):
        raise RuntimeError(
            f"LOSVD shape {losvd.shape} != (nSpat, nVel, nComp) "
            f"with nSpat={nSpat}, nComp={nComp}"
        )

    # Plan shards/tiles and create models array in a dedicated v3 store
    plan = _make_plan(nSpat, nComp, nPop, nLSpec, S, C, P, shard_S, shard_C, shard_P)
    mroot = _open_models_v3(models_path)
    marr = _ensure_models_array(mroot, shape=plan.shape, chunks=plan.chunks, shard=plan.shard)
    logger.log(
        f"[HyperCube] models v3: path={models_path}, shape={marr.shape}, "
        f"chunks={marr.chunks}, shard={plan.shard}"
    )

    # Manifest in base root (/HyperCube attrs)
    try:
        if "HyperCube" in base:
            hg = base["HyperCube"]
        else:
            # compatible creation for v2/v3
            try:
                hg = base.require_group("HyperCube")
            except Exception:
                hg = base.create_group("HyperCube")
    except Exception:
        # If base is totally empty, create a minimal group path
        base = _open_base(base_path)
        try:
            hg = base.require_group("HyperCube")
        except Exception:
            hg = base.create_group("HyperCube")

    core = _manifest_core(
        plan.shape, plan.chunks, plan.shard, "f4"
    )
    # pointer to external models store kept *outside* the digest
    models_store_abs = _canon(models_path)
    planned = _with_digest({**core, "extra": (extra_manifest or {})})
    planned["models_store"] = models_store_abs  # not part of the digest

    # ----- BEGIN: verbose reuse diagnostics -----
    prev = hg.attrs.get("manifest", None)

    # canonical absolute pointer (don’t include in digest equality)
    try:
        models_store_abs = str(Path(models_path).resolve())
    except Exception:
        models_store_abs = str(Path(models_path).absolute())

    has_models = "models" in mroot
    if not has_models:
        logger.log("[HyperCube] Reuse check: models array not found in models store "
                f"({models_path}); will build.")
    else:
        marr = mroot["models"]

        # Core checks
        shape_ok  = tuple(marr.shape)  == tuple(plan.shape)
        chunks_ok = tuple(marr.chunks) == tuple(plan.shard)   # super-chunk now
        dtype_ok  = str(marr.dtype)    == "float32"

        codecs_list = getattr(marr, "codecs", None)
        is_sharded = False
        inner_found = None
        if codecs_list is not None:
            for c in codecs_list:
                name = getattr(c, "name", type(c).__name__)
                if str(name).lower() in ("sharding", "shardingcodec"):
                    is_sharded = True
                    inner_found = tuple(getattr(c, "chunk_shape", ()) or ())
                    break

        # If sharded, inner chunk must match our compute/inner-chunk
        inner_ok = (not is_sharded) or (inner_found == tuple(plan.chunks))

        complete = bool(mroot.attrs.get("complete", False))
        man_ok = _man_equal(prev, planned) if isinstance(prev, dict) else False

        # Detailed log with found vs expected
        logger.log("[HyperCube] Reuse diagnostics:")
        logger.log(f"    models store: {models_path}")
        logger.log(f"    has_models:   {has_models}")
        logger.log(f"    complete:     {complete}")
        logger.log(f"    shape_ok:     {shape_ok} (found {tuple(marr.shape)} "
                f"vs expected {tuple(plan.shape)})")
        logger.log(f"    chunks_ok:    {chunks_ok} (found {tuple(marr.chunks)} "
                f"vs expected super-chunk {tuple(plan.shard)})")
        logger.log(f"    is_sharded:   {is_sharded}")
        logger.log(f"    inner_ok:     {inner_ok} (found inner {inner_found} "
                f"vs expected {tuple(plan.chunks)})")
        logger.log(f"    man_equal*:   {man_ok}  (*digest ignores models_store path)")

        # Decide reuse
        if (check != "force" and shape_ok and chunks_ok and dtype_ok and inner_ok and complete):
            # Refresh manifest pointer (kept outside digest) and return
            new_manifest = dict(planned)
            new_manifest["models_store"] = models_store_abs
            hg.attrs["manifest"] = new_manifest
            hg.attrs["manifest_hash"] = planned.get("digest", "")
            logger.log("[HyperCube] Reusing existing models; manifest refreshed.")
            return

        # If we’re here, something failed — spell it out
        reasons = []
        if check == "force":               reasons.append("check='force'")
        if not complete:                   reasons.append("not marked complete")
        if not shape_ok:                   reasons.append("shape mismatch")
        if not chunks_ok:                  reasons.append("chunks mismatch")
        if not dtype_ok:                   reasons.append("dtype mismatch")
        if not inner_ok:                   reasons.append("shard mismatch or not sharded")
        if isinstance(prev, dict) and not man_ok:
            reasons.append("manifest mismatch (structural)")
        if reasons:
            logger.log("[HyperCube] Rebuild required because: " + ", ".join(reasons))
        else:
            logger.log("[HyperCube] Rebuild required (unspecified reason).")
    # ----- END: verbose reuse diagnostics -----

    # Build (one worker per shard)
    R_T = np.asarray(rebin_matrix.T, dtype=np.float64, order="C")
    init_args = (
        str(base_path),
        str(models_path),
        R_T,
        np.asarray(templates_fft, order="C"),
        np.asarray(tem_pix, order="C"),
        np.asarray(obs_pix, order="C"),
        (plan.chunks[0], plan.chunks[1], plan.chunks[2]),
    )

    logger.log(
        f"[HyperCube] Plan: shards={len(plan.tiles)}, chunks={plan.chunks}, "
        f"shard={plan.shard}, workers={n_workers}"
    )
    with ProcessPoolExecutor(
        max_workers=n_workers,
        initializer=_init_worker,
        initargs=init_args,
    ) as pool:
        futs = [pool.submit(_worker_fill_shard, sel) for sel in plan.tiles]
        for fut in tqdm(as_completed(futs), total=len(futs), desc="[HyperCube] shards"):
            fut.result()

    # Save manifest/pointer into base/HyperCube attrs
    hg.attrs["manifest"] = planned
    hg.attrs["manifest_hash"] = planned.get("digest", "")
    logger.log("[HyperCube] Build complete; manifest written.")

    # mark models store as complete (so we can trust it on next run)
    mroot.attrs["complete"] = True

    # refresh manifest with pointer
    new_manifest = dict(planned)
    new_manifest["models_store"] = models_store_abs
    hg.attrs["manifest"] = new_manifest
    hg.attrs["manifest_hash"] = planned.get("digest", "")
    logger.log("[HyperCube] Manifest written; models marked complete.")
