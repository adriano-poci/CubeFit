# -*- coding: utf-8 -*-
r"""
    pipeline_runner.py
    Adriano Poci
    University of Oxford
    2025

    Platforms
    ---------
    Unix, Windows

    Synopsis
    --------
    High-level CubeFit pipeline orchestration: runs per-aperture or global
    Kaczmarz NNLS fits, manages Zarr storage, provides reference and diagnostic
    NNLS fits, and supports continuum/velocity expansion and plotting.

    Authors
    -------
    Adriano Poci <adriano.poci@physics.ox.ac.uk>

History
-------
v1.0:   Initial pipeline design for CubeFit. 2025
v1.1:   Added global (full-cube) Kaczmarz and block constraint support. 2025
v1.2:   Supports continuum, velocity-shift, and reference fits. 2025
v1.3:   Full workflow Zarr integration and flexible test sub-selection. 2025
"""

from __future__ import annotations

import os, sys
from time import time
from concurrent.futures import ProcessPoolExecutor
import pathlib as plp
from functools import partial
from tqdm import tqdm
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import nnls
from scipy.fft import next_fast_len
from numpy.polynomial.legendre import legvander

from hypercube_reader import HyperCubeReader, ReaderCfg
from kaczmarz_solver import KaczmarzSolver, fit_global_kaczmarz, fit_global_kaczmarz_tiled
from CubeFit.zarr_manager import ZarrManager
from CubeFit.model_cube import ModelCube
from CubeFit.parallel import process_aperture
from CubeFit.plotting import plot_aperture_fit, plot_model_decomposition
from CubeFit.logger import get_logger
from CubeFit.cube_bcd import bcd_global_by_component_and_spatial_block_parallel
from dynamics.IFU.Constants import UnitStr

UTS = UnitStr()
logger = get_logger()

def sanitize_kwargs(kwargs, *args):
    """Remove all keys in args from kwargs dict (in-place)."""
    for k in args:
        kwargs.pop(k, None)
    return kwargs

# ------------------------------------------------------------------------------

def mean_subset_nnls_init(
    y_cube, losvd_cube, templates_fft, rebin_matrix,
    tem_pix, obs_pix, nLSpec, nComp, nPop,
    frac_subset=0.2,
    seed=None,
    logger=None,
):
    """
    Use the mean observed spectrum and LOSVD of a random subset of apertures to
    initialize x (same for all apertures). Times the operation and logs the
    elapsed time.

    Parameters
    ----------
    y_cube : ndarray
        Observed data, shape (nSpat, nLSpec).
    losvd_cube : ndarray
        LOSVDs, shape (nSpat, nVel, nComp).
    templates_fft, rebin_matrix : arrays for ModelCube.
    tem_pix, obs_pix : arrays for ModelCube.
    nLSpec, nComp, nPop : int
    frac_subset : float
        Fraction of apertures to use for the mean (0 < frac ≤ 1).
    seed : int or None
        RNG seed.
    logger : Logger or None
        Optional logger for progress.

    Returns
    -------
    x_init : ndarray
        Initial guess for all weights, shape (nComp, nSpat, nPop).
    """
    if logger:
        logger.log("[NNLS-init] Starting mean subset NNLS initialization...", flush=True)
    t0 = time.perf_counter()

    nSpat = y_cube.shape[0]
    rng = default_rng(seed)
    n_subset = max(1, int(frac_subset * nSpat))
    subset_indices = rng.choice(nSpat, size=n_subset, replace=False)

    y_mean = np.mean(y_cube[subset_indices], axis=0)
    losvd_mean = np.mean(losvd_cube[subset_indices], axis=0)
    A = ModelCube(
        templates_fft,
        rebin_matrix,
        losvd_mean,
        tem_pix,
        obs_pix,
    ).convolve()
    A_flat = A.reshape(nLSpec, nComp * nPop)
    x0, _ = nnls(A_flat, y_mean)
    x_init = np.tile(x0.reshape(nComp, 1, nPop), (1, nSpat, 1))

    elapsed = time.perf_counter() - t0
    if logger:
        logger.log(
            f"[NNLS-init] Mean subset NNLS initialization complete in "
            f"{elapsed/60:.2f} min ({elapsed:.1f} sec).", flush=True
        )
    return x_init

# ------------------------------------------------------------------------------

def _expand_comp_weights(w, nComp, nPop, *, row_order="c-major"):
    """
    Expand component-only weights w:(nComp,) to (nComp*nPop,) to match x.
    row_order:
      - "c-major": row = c*nPop + p  (what the reader uses by default)
      - "p-major": row = p*nComp + c
    """
    if w is None:
        return None
    w = np.asarray(w, dtype=np.float64)
    if w.ndim != 1 or w.size != nComp:
        raise ValueError(f"orbit_weights must be shape (nComp,), got {w.shape}")
    if row_order == "c-major":
        # [w_c] repeated for each population p within component c
        return np.repeat(w, nPop)
    elif row_order == "p-major":
        # populations outer, components inner
        return np.tile(w, nPop)
    else:
        raise ValueError("row_order must be 'c-major' or 'p-major'")

# ------------------------------------------------------------------------------

class PipelineRunner:
    """
    Orchestrates CubeFit Kaczmarz NNLS fits for both classic per-aperture
    and global (single-x) solves, including reference NNLS and continuum
    diagnostics.
    """

    def __init__(
        self,
        zarr_dir: str,
        nSpat: int,
        nComp: int,
        nVel: int,
        nPop: int,
        nLSpec: int,
        nTSpec: int,
        tem_pix,
        obs_pix,
        lOrder: int = 3,
    ):
        """
        Initialise PipelineRunner and associated ZarrManager.

        Parameters
        ----------
        zarr_dir : str
            Path to Zarr root directory.
        nSpat : int
            Number of spatial apertures (spaxels).
        nComp : int
            Number of dynamical components.
        nVel : int
            Number of LOSVD velocity bins.
        nPop : int
            Number of template populations (flattened).
        nLSpec : int
            Number of observed spectral pixels.
        nTSpec : int
            Number of template spectral pixels (padded grid).
        tem_pix : ndarray
            Template wavelength grid (nTSpec,).
        obs_pix : ndarray
            Observed wavelength grid (nLSpec,).
        lOrder : int, default=3
            Legendre continuum order for reference fits.
        """

        self.mgr = ZarrManager(
            zarr_dir,
            nSpat,
            nComp,
            nVel,
            nPop,
            nLSpec,
            nTSpec,
        )
        self.z = self.mgr.z
        self.zarr_dir = zarr_dir
        self.nSpat = nSpat
        self.nComp = nComp
        self.nVel = nVel
        self.nPop = nPop
        self.nLSpec = nLSpec
        self.nTSpec = nTSpec
        self.tem_pix = tem_pix
        self.obs_pix = obs_pix
        self.lOrder = lOrder
        self.templates = self.z["Templates"][:]

        # Define FFT size once
        self.fft_size = next_fast_len(self.nTSpec + self.nVel - 1)

        # Globally precompute FFT of templates (once!)
        self.templates_fft = np.fft.fft(self.templates, n=self.fft_size, axis=1)
        # Globally cache the rebin matrix (once!)
        self.rebin_matrix = ModelCube.compute_rebin_matrix(self.tem_pix,
            self.obs_pix)

        self.mask = self.z["Mask"][:] if "Mask" in self.z else None

        logger.log('[CubeFit] Initialised PipelineRunner with FFT templates '\
            f"({self.templates_fft.shape}) and rebin matrix "\
            f"({self.rebin_matrix.shape})", flush=True)
 
    # --------------------------------------------------------------------------

    def solve_all_bcd(
        self,
        max_iter: int = 5,
        nnls_solver: str = "lbfgsb",
        n_workers: int = 8,
        verbose: bool = True,
    ):
        """
        Run a global block coordinate descent (BCD) fit for the entire data cube,
        updating all weights for one dynamical component at a time (block by component).

        Parameters
        ----------
        max_iter : int
            Number of BCD iterations (passes over all components).
        nnls_solver : str
            Solver for each block ('lbfgsb' or 'SLSQP').
        n_workers : int
            Number of parallel processes to use (<= nComp).
        verbose : bool
            Print progress and diagnostics.

        Returns
        -------
        x_bcd : ndarray
            Global solution vector, shape (nComp, nSpat, nPop).
        """

        logger.log("[CubeFit] Starting global BCD fit...", flush=True)

        # Load necessary arrays from zarr
        y_cube = self.z["DataCube"][:]       # (nSpat, nLSpec)
        losvd_cube = self.z["LOSVD"][:]      # (nSpat, nVel, nComp)
        templates_fft = self.templates_fft    # (nPop, fft_size)
        rebin_matrix = self.rebin_matrix      # (nLSpec, nTSpec)
        tem_pix = self.tem_pix
        obs_pix = self.obs_pix
        nLSpec = self.nLSpec
        nComp = self.nComp
        nPop = self.nPop

        # First, get a good initial guess:
        x_init = mean_subset_nnls_init(
            y_cube, losvd_cube, templates_fft, rebin_matrix,
            tem_pix, obs_pix, nLSpec, nComp, nPop)

        # Then run BCD:
        x_bcd = bcd_global_by_component_and_spatial_block_parallel(
            y_cube, losvd_cube, templates_fft, rebin_matrix,
            tem_pix, obs_pix, nLSpec, nComp, nPop,
            spatial_block_size=32,
            max_iter=max_iter,
            nnls_solver=nnls_solver,
            n_workers=n_workers,
            x_init=x_init,
            verbose=True)

        logger.log("[CubeFit] BCD fit complete. Saving results...", flush=True)
        self.z['X_global'][:] = x_bcd

        logger.log("[CubeFit] Global BCD fit and save complete.", flush=True)
        return x_bcd

    # --------------------------------------------------------------------------

    def solve_all(
        self,
        *,
        global_fit: bool = True,
        mode: str = "tiled",           # "tiled" or "full" when global_fit=True
        epochs: int = 1,
        pixels_per_aperture: int = 256,
        max_rows_in_mem: int = 8192,   # used in tiled mode
        reader_prefetch: int = 8,
        reader_workers: int = 4,
        lr: float = 0.25,
        project_nonneg: bool = True,   # kept for API compatibility; true-prior path enforces NN inside
        orbit_weights=None,            # (nComp,) component prior
        verbose: bool = False,
        zarr_path: str | None = None,
        spaxel_indices=None,
        row_order: str = "c-major",
    ):
        """
        Orchestrate fitting against the 4‑D HyperCube/models: (nSpat, nComp, nPop, nLSpec).

        When `global_fit=True`, performs a **global true‑prior** fit: a single x ∈ R^{nComp*nPop}
        shared across all apertures, with per‑component weights incorporated **during** updates.
        Two modes are supported:
        - mode="tiled": (C,P)-tiled streaming (bounded RAM).
        - mode="full" : full‑aperture streaming.

        Parameters
        ----------
        global_fit : bool
            If True, solve one global x across all apertures with true‑prior Kaczmarz.
            If False, run legacy per‑aperture fits (returns dict of solutions).
        mode : {"tiled","full"}
            Reader strategy for global fit.
        epochs, pixels_per_aperture, max_rows_in_mem, reader_prefetch, reader_workers :
            Performance knobs. See hypercube_builder/reader docstrings for guidance.
        lr : float
            Kaczmarz relaxation/learning rate.
        orbit_weights : array-like or None, shape (nComp,)
            Per‑component positive weights (true prior). If None, unweighted Kaczmarz is used.
        row_order : {"c-major","p-major"}
            Row ordering convention for expanding component weights to rows.
        zarr_path : str or None
            Zarr store path. If None, falls back to attributes on `self`.

        Returns
        -------
        If global_fit:
            x_global : np.ndarray, shape (nComp*nPop,)
            residuals : dict[str, float] (summary metrics)
        Else:
            x_per_spaxel : dict[int, np.ndarray]
            residuals    : dict[int, float]
        """

        t0 = time()

        # Discover Zarr path
        zpath = (
            zarr_path
            or getattr(self, "zarr_path", None)
            or getattr(self, "zarr_store", None)
            or getattr(self, "zarrDir", None)
            or getattr(self, "zarr", None)
        )
        if zpath is None:
            raise RuntimeError("solve_all: zarr_path not provided and runner has no zarr path attribute.")

        # Build reader
        cfg = ReaderCfg(
            flatten=True,
            c_tile=None, p_tile=None,          # default to storage chunks
            max_rows_in_mem=max_rows_in_mem,
            prefetch=reader_prefetch,
            max_workers=reader_workers,
            apply_mask=True,
            ensure_c_contig=True,
            dtype="float64",
        )
        reader = HyperCubeReader(zpath, cfg=cfg)
        logger.log(f"[Pipeline] HyperCube ready: shape=(S={reader.nSpat}, C={reader.nComp}, "
            f"P={reader.nPop}, L={reader.nLSpec}), chunks={reader._models.chunks}")

        # Spaxel list
        if spaxel_indices is None:
            spaxel_indices = np.arange(reader.nSpat, dtype=np.int64)
        else:
            spaxel_indices = np.array(list(spaxel_indices), dtype=np.int64)

        # Prepare solver
        solver = KaczmarzSolver(lr=lr)

        # ----- TRUE PRIOR handling (component weights) -----
        comp_weights = None
        if orbit_weights is None:
            logger.log("[Pipeline] No component prior provided; running unweighted Kaczmarz.")
        else:
            w = np.asarray(orbit_weights, dtype=np.float64)
            if w.ndim != 1 or w.size != reader.nComp:
                raise ValueError(f"[Pipeline] orbit_weights must be shape ({reader.nComp},), got {w.shape}")
            # Clamp strictly positive
            bad = np.count_nonzero(w <= 0)
            if bad:
                logger.log(f"[Pipeline] WARNING: {bad} non‑positive component weights; clamping to 1e-12.")
                w = np.maximum(w, 1e-12)
            comp_weights = w
            logger.log(f"[Pipeline] Prior: comp_weights stats → min={w.min():.3g}, max={w.max():.3g}, mean={w.mean():.3g}; row_order={row_order}")

        # ========================= GLOBAL FIT =========================
        if global_fit:
            logger.log(f"[Pipeline] Global true‑prior fit starting → mode={mode}, epochs={epochs}, "
                f"pixels/ap={pixels_per_aperture}, prefetch={reader_prefetch}, workers={reader_workers}, lr={lr}")

            if mode not in ("tiled", "full"):
                raise ValueError("solve_all: mode must be 'tiled' or 'full' when global_fit=True")

            if mode == "tiled":
                logger.log(f"[Pipeline] Tiled reader: C_tile={reader.c_tile}, P_tile={reader.p_tile}, "
                    f"rows_per_tile={reader.c_tile * reader.p_tile}")
                x = fit_global_kaczmarz_tiled(
                    reader,
                    epochs=epochs,
                    pixels_per_aperture=pixels_per_aperture,
                    comp_weights=comp_weights,      # TRUE PRIOR
                    row_order=row_order,
                    rng=None,
                    solver=solver,
                )
            else:
                x = fit_global_kaczmarz(
                    reader,
                    epochs=epochs,
                    pixels_per_aperture=pixels_per_aperture,
                    comp_weights=comp_weights,      # TRUE PRIOR
                    row_order=row_order,
                    rng=None,
                    solver=solver,
                )

            dur = time() - t0
            logger.log(f"[Pipeline] Global fit complete in {dur:.2f}s. ||x||₂={np.linalg.norm(x):.4e}, "
                f"min={x.min():.3g}, max={x.max():.3g}")

            # Optional quick validation sweep on a subset of apertures
            residuals = {}
            try:
                n_val = min(64, spaxel_indices.size)
                if n_val > 0:
                    idx_val = spaxel_indices[:n_val]
                    logger.log(f"[Pipeline] Validation: computing RMS on {n_val} aperture(s)...")
                    rms_list = []
                    for i, A_T, y in reader.iter_apertures(
                        idx_val, prefetch=reader_prefetch, max_workers=reader_workers
                    ):
                        yhat = A_T.T @ x
                        r = y - yhat
                        rms_list.append(float(np.sqrt(np.mean(r * r))))
                    residuals["rms_val_mean"] = float(np.mean(rms_list)) if rms_list else float("nan")
                    residuals["rms_val_std"] = float(np.std(rms_list)) if rms_list else float("nan")
                    logger.log(f"[Pipeline] Validation RMS → mean={residuals['rms_val_mean']:.4g}, "
                        f"std={residuals['rms_val_std']:.4g}")
            except Exception as e:
                logger.log(f"[Pipeline] Validation skipped: {e}")

            return x, residuals

        # ====================== PER-APERTURE (legacy) ======================
        logger.log("[Pipeline] Per‑aperture fit path selected (true prior applies to global fit only).")
        x_per = {}
        res_per = {}

        from kaczmarz_solver import KaczmarzSolver as _KS  # reuse same solver
        solver = _KS(lr=lr)

        for i, A_T, y in tqdm(
            HyperCubeReader(zpath, cfg=cfg).iter_apertures(
                spaxel_indices, prefetch=reader_prefetch, max_workers=reader_workers
            ),
            total=len(spaxel_indices),
            desc="[Pipeline] per‑aperture",
        ):
            A = A_T.T  # (L, N)
            xi, residuals_list = solver.solve(A, y, verbose=verbose)
            if project_nonneg:
                np.maximum(xi, 0.0, out=xi)
            x_per[int(i)] = xi
            res = (float(residuals_list[-1]) if residuals_list else
                float(np.sqrt(np.mean((y - A @ xi) ** 2))))
            res_per[int(i)] = res

        return x_per, res_per
    
    # --------------------------------------------------------------------------

    def _generate_default_initialization(self):
        # Simple default: uniform small initialization
        n_weights = self.nComp * self.nPop
        return np.full(n_weights, 1e-4)

    # --------------------------------------------------------------------------

    def _reference_nnls(
        self,
        verbose=True,
        orbit_weights=None,
        lam=None,
        N_stack=16,
        max_iters=5000,
        solver_tolerance=1e-3,
        nProcs=8,
    ):
        """
        Compute reference NNLS (or constrained) fit for diagnostic purposes.
        
        Attempts a quick, constrained or unconstrained NNLS fit to a stack of
        spatial spectra. If solver fails or reaches iteration limits, logs a clear
        warning and returns default initialization to not hinder the global workflow.

        Parameters
        ----------
        verbose : bool, default=True
            Print solver details to log.
        orbit_weights : ndarray or None
            If set (shape nComp, sum to 1), enforce relative block sums.
        lam : float or None
            Soft penalty weight for orbit_weights deviation.
        N_stack : int, default=1
            Number of spatial apertures to stack.
        max_iters : int, default=5000
            Maximum solver iterations to prevent hanging.
        solver_tolerance : float, default=1e-3
            Solver convergence tolerance (abs & rel).

        Returns
        -------
        x_ref : ndarray
            Reference solution vector.
        res : float
            Residual norm of reference fit (np.nan if failed).
        indices : ndarray
            Indices of spatial apertures used.
        """

        logger.log("[Ref NNLS] Starting reference NNLS fit...", flush=True)
        indices = np.linspace(0, self.nSpat - 1, N_stack, dtype=int)
        y_stack, A0 = [], []

        # Use HyperCube!
        models_array = self.z["HyperCube/models"]
        # shape (n_batches, batch_size, nComp, nPop, nLSpec)
        batch_size = models_array.shape[1]
        batch_indices = [
            np.arange(b, min(b + batch_size, self.nSpat))
            for b in range(0, self.nSpat, batch_size)
        ]
        index_to_batch = {}
        for batch_idx, spat_indices in enumerate(batch_indices):
            for i, s in enumerate(spat_indices):
                index_to_batch[s] = (batch_idx, i)

        start_time = time()
        logger.log(f"[Ref NNLS] Stacking {N_stack} apertures: {indices.tolist()}", flush=True)
        for s in indices:
            y_stack.append(self.z["DataCube"][s])
            batch_idx, within_batch = index_to_batch[s]
            model_batch = models_array[batch_idx]
            # model_batch[within_batch]: (nComp, nPop, nLSpec)
            A_s = np.transpose(model_batch[within_batch], (2, 0, 1))
            # (nLSpec, nComp, nPop)
            A_s = A_s.reshape(self.nLSpec, self.nComp * self.nPop)
            A0.append(A_s)
        end_time = time()
        logger.log(f"[Ref NNLS] Stacking took {end_time - start_time:.2f} seconds", flush=True)

        y_stack = np.concatenate(y_stack, axis=0)
        A0_flat = np.concatenate(A0, axis=0)

        mask = self.mask
        y_stack_full = y_stack.copy()
        A0_flat_full = A0_flat.copy()
        if mask is not None:
            mask_big = np.tile(mask, N_stack)
            y_stack, A0_flat = y_stack[mask_big], A0_flat[mask_big, :]

        C = self._continuum_terms(self.obs_pix, order=self.lOrder)
        if verbose:
            logger.log(f"[Ref NNLS] Continuum terms shape: {C.shape}", flush=True)
        if C.shape[1] > 0:
            C *= 1e-3
            C_tiled = np.tile(C, (N_stack, 1))
            A0_flat_full = np.hstack([A0_flat_full, C_tiled]) # before masking
            if mask is not None:
                C_tiled = C_tiled[mask_big, :]
            A0_flat = np.hstack([A0_flat, C_tiled])

        # Solve
        try:
            import cvxpy as cp
        except ImportError:
            logger.log("[Ref NNLS] CVXPY not installed, falling back.", flush=True)
            return np.zeros(A0_flat.shape[1]), np.nan, indices

        x = cp.Variable(A0_flat.shape[1], nonneg=True)

        lam = 1e-12

        if orbit_weights is not None:
            nComp, nPop = self.nComp, self.nPop
            block_sums = [cp.sum(x[c*nPop:(c+1)*nPop]) for c in range(nComp)]
            if lam and lam > 0:
                from scipy.optimize import nnls
                x0, _ = nnls(A0_flat, y_stack)
                total = sum(x0[c*nPop:(c+1)*nPop].sum() for c in range(nComp))
                target_block_sums = orbit_weights * total
                penalty = lam * cp.sum_squares(cp.hstack(block_sums) - target_block_sums)
                objective = cp.Minimize(cp.sum_squares(A0_flat @ x - y_stack) + penalty)
                constraints = []
                penalty_type = 'soft'
            else:
                S_tot = cp.sum(cp.hstack(block_sums))
                constraints = [block_sums[c] == orbit_weights[c] * S_tot for c in range(nComp)]
                objective = cp.Minimize(cp.sum_squares(A0_flat @ x - y_stack))
                penalty_type = 'hard'
        else:
            constraints = []
            objective = cp.Minimize(cp.sum_squares(A0_flat @ x - y_stack))
            penalty_type = 'unconstrained'

        prob = cp.Problem(objective, constraints)
        try:
            prob.solve(
                solver=cp.OSQP,
                max_iter=max_iters,
                eps_abs=solver_tolerance,
                eps_rel=solver_tolerance,
                verbose=verbose)
        except cp.SolverError as e:
            logger.log(f"[Ref NNLS WARNING] cvxpy solver failed: {e}",
                flush=True)
            logger.log('[Ref NNLS WARNING] Returning zeros due to solver '\
                'failure.', flush=True)
            x_ref = np.zeros(A0_flat.shape[1])

        status = prob.status
        if status in ["infeasible", "unbounded", "solver_error", "max_iters"]:
            logger.log(
                f"[Ref NNLS WARNING] Solver terminated with status: {status}.",
                flush=True,
            )
            return np.zeros(A0_flat.shape[1]), np.nan, indices

        x_ref = x.value
        if x_ref is None or np.all(x_ref == 0):
            logger.log('[Ref NNLS WARNING] Solver returned empty or zero '\
                'solution.', flush=True)
            return np.zeros(A0_flat.shape[1]), np.nan, indices

        res = np.linalg.norm(y_stack - A0_flat @ x_ref)

        plot_dir = plp.Path(self.mgr.root_dir) / 'plots'
        plot_dir.mkdir(parents=True, exist_ok=True)
        fig_path = plot_dir / 'reference_fit_stacked.png'
        plot_aperture_fit(y_stack_full, A0_flat_full @ x_ref,
            np.exp(self.obs_pix), aperture_index="stacked",
            mask=mask_big,
            wavelength_str=rf"$\log\left(\lambda [{UTS.angst}]\right)$")
        plt.savefig(fig_path, dpi=150)
        plt.close()

        logger.log(f"[Ref NNLS] Completed ({penalty_type}). Residual: "\
            f"{res:.6f}", flush=True)
        logger.log(f"[Plot] saved to {fig_path}", flush=True)

        def estimate_pixel_shift(y_obs, y_mod, max_shift=10):
            # zero-mean to avoid slope/continuum effects
            a = y_obs - np.mean(y_obs)
            b = y_mod - np.mean(y_mod)
            # normalized cross-correlation for shifts in [-max_shift, max_shift]
            best = (0, -np.inf)
            for sh in range(-max_shift, max_shift+1):
                if sh < 0:
                    aa, bb = a[-sh:], b[:len(b)+sh]
                elif sh > 0:
                    aa, bb = a[:len(a)-sh], b[sh:]
                else:
                    aa, bb = a, b
                if aa.size < 8:  # too short
                    continue
                num = float(np.dot(aa, bb))
                den = float(np.linalg.norm(aa) * np.linalg.norm(bb)) + 1e-12
                corr = num / den
                if corr > best[1]:
                    best = (sh, corr)
            return best  # (shift_in_pixels, corr)

        # Example: pick one aperture used in the stack
        s0 = int(indices[0])
        # build its model spectrum from HyperCube + x_ref (same A used in fit)
        batch_idx, within = index_to_batch[s0]
        A_s = np.asarray(models_array[batch_idx, within], dtype=np.float64)  # (nComp,nPop,nLSpec)
        # x_ref includes continuum coeffs if C_tiled was appended.
        nWeights = int(self.nComp*self.nPop)
        n_extra  = int(x_ref.size - nWeights)  # continuum or other extras

        if n_extra > 0:
            logger.log(f"[Ref NNLS] Trimming {n_extra} extra coeffs (e.g. continuum) "
                    f"from x_ref for model reconstruction.", flush=True)

        # Use only the first nComp*nPop entries for the spectral model
        x_ref_w = x_ref[:nWeights]
        if x_ref_w.size < nWeights:
            # pad (very unlikely, but keeps plotting robust)
            x_ref_w = np.pad(x_ref_w, (0, nWeights - x_ref_w.size))

        xB = x_ref_w.reshape(nComp, nPop)

        # Model for this aperture using the HyperCube basis:
        # y_mod[p] = sum_{c,k} A_s[c,k,p] * xB[c,k]
        y_mod = np.einsum('ckp,ck->p', A_s, xB, optimize=True)
        y_obs = self.z["DataCube"][s0].astype(np.float64)

        shift, corr = estimate_pixel_shift(y_obs[mask], y_mod[mask])
        logger.log(f"[Ref NNLS] pixel shift estimate (aper {s0}): {shift} (corr={corr:.3f})", flush=True)

        return x_ref, res, indices
    
    # --------------------------------------------------------------------------

    @staticmethod
    def _continuum_terms(x_pix, order=3):
        """
        Generate a Legendre polynomial continuum basis (excluding constant term).

        Parameters
        ----------
        x_pix : ndarray
            1D pixel centres (typically observed grid), length nPix.
        order : int
            Order of the Legendre polynomial (must be >= 1).

        Returns
        -------
        C : ndarray, shape (nPix, order)
            Legendre continuum basis matrix (excluding constant term).
        """
        x = 2 * (x_pix - np.min(x_pix)) / np.ptp(x_pix) - 1.0
        return legvander(x, order)[:, 1:]
    
    # --------------------------------------------------------------------------

    @staticmethod
    def _velocity_shift_terms(templates_flat):
        """
        Compute the finite-difference velocity derivative of each template.

        Parameters
        ----------
        templates_flat : ndarray, shape (nPop, nTSpec)
            Flattened templates (not rebinned).

        Returns
        -------
        dT : ndarray, shape (nPop, nTSpec)
            Central-difference velocity derivative (pixels).
        """
        # Central difference: shape (nPop, nTSpec-2)
        d = 0.5 * (templates_flat[:, 2:] - templates_flat[:, :-2])
        # Pad ends with zeros to preserve (nPop, nTSpec)
        pad_left = np.zeros((templates_flat.shape[0], 1), dtype=templates_flat.dtype)
        pad_right = np.zeros((templates_flat.shape[0], 1), dtype=templates_flat.dtype)
        return np.hstack([pad_left, d, pad_right])

    # --------------------------------------------------------------------------
