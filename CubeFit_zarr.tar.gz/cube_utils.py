# -*- coding: utf-8 -*-
r"""
    cube_utils.py
    Adriano Poci
    University of Oxford
    2025

    Platforms
    ---------
    Unix, Windows

    Synopsis
    --------
    High-level scientific utilities for CubeFit:
    - Provides fast, memory-efficient NNLS initialization (mean-spectrum, cluster, or random subset)
    - Efficient global loss computation for diagnostics (with progress bar)
    - Utility functions for array reshaping, batching, and random sampling
    - Designed for very large data cubes, parallel pipelines, and reproducible initialization

    Authors
    -------
    Adriano Poci <adriano.poci@physics.ox.ac.uk>

History
-------
1.0:    12 August 2025
"""

import numpy as np
from scipy.optimize import nnls
from tqdm import tqdm
from numpy.random import default_rng

# ------------------------------------------------------------------------------

def comp_loss_for_total(
    x, y_cube, zarr_mgr, batch_size, nSpat, nLSpec, nComp, nPop
):
    y_model_cube = []
    batch_indices = [
        np.arange(b, min(b + batch_size, nSpat))
        for b in range(0, nSpat, batch_size)
    ]
    for batch_idx, spat_indices in enumerate(batch_indices):
        n_ap_batch = len(spat_indices)
        model_batch = zarr_mgr.get_hypercube_batch(batch_idx)
        for i, s in enumerate(spat_indices):
            weights = x[:, s, :]
            A_sum = np.sum(model_batch[i] * weights[:, None, :], axis=(0,2))
            y_model_cube.append(A_sum)
    y_model_cube = np.vstack(y_model_cube)
    resids = y_cube - y_model_cube
    return 0.5 * np.sum(resids ** 2)

# ------------------------------------------------------------------------------

def random_subset_indices(nSpat, frac_subset=0.2, seed=None):
    """
    Utility to return indices for a random subset of apertures.
    """
    rng = default_rng(seed)
    n_subset = max(1, int(frac_subset * nSpat))
    return rng.choice(nSpat, size=n_subset, replace=False)

# ------------------------------------------------------------------------------

def flatten_x(x):
    """
    Utility: Flatten a (nComp, nSpat, nPop) solution array for storage or fitting.
    """
    return x.reshape(-1)

def unflatten_x(x_flat, nComp, nSpat, nPop):
    """
    Utility: Unflatten a solution vector into (nComp, nSpat, nPop).
    """
    return x_flat.reshape(nComp, nSpat, nPop)

# ------------------------------------------------------------------------------
