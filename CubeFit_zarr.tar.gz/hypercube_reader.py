# -*- coding: utf-8 -*-
r"""
    hypercube_reader.py
    Adriano Poci
    University of Oxford
    2025

    Platforms
    ---------
    Unix, Windows

    Synopsis
    --------
    Manages Zarr data storage for CubeFit pipeline, including creation, loading,
    and validation of large, chunked arrays (templates, data cube, LOSVD, weights).
    Supports buffered template grids for safe convolution.

    Authors
    -------
    Adriano Poci <adriano.poci@physics.ox.ac.uk>

History
-------
v1.0:   Initial design and validation. 14 August 2025
"""

from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional, Tuple, Union
import numpy as np
import zarr
from concurrent.futures import ThreadPoolExecutor, as_completed

# -----------------------------------------------------------------------------
# Logger (use pipeline logger if present, otherwise minimal fallback)
# -----------------------------------------------------------------------------

try:
    from CubeFit.logger import get_logger  # type: ignore
    logger = get_logger()
except Exception:  # pragma: no cover
    class _Logger:
        def log(self, *msg): print(*msg)
    logger = _Logger()

# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------

@dataclass
class ReaderCfg:
    """
    Reader configuration (backward-compatible).

    Parameters
    ----------
    dtype : str
        Target dtype for arrays returned to the solver ("float64" default).
    apply_mask : bool
        If True and a 1-D 'SpecMask' exists, multiply spectra by it.
    ensure_c_contig : bool
        Ensure returned arrays are C-contiguous in memory.
    mask_key : str
        Dataset name for the spectral mask (length nLSpec).

    # Legacy / kept for API compatibility (no-ops for now):
    flatten : Optional[bool]
        If provided and read_aperture(flatten=None), we use this default.
    c_tile, p_tile : Optional[int]
        Was used for tiled reading; ignored here.
    max_rows_in_mem : Optional[int]
        Legacy streaming hint; ignored here.
    prefetch : Optional[Union[int,bool]]
        Legacy async prefetch hint; ignored here.
    max_workers : Optional[int]
        Legacy thread/process hint; ignored here.
    """
    dtype: str = "float64"
    apply_mask: bool = False
    ensure_c_contig: bool = True
    mask_key: str = "SpecMask"

    # Compatibility fields (no-ops, but accepted)
    flatten: Optional[bool] = None
    c_tile: Optional[int] = None
    p_tile: Optional[int] = None
    max_rows_in_mem: Optional[int] = None
    prefetch: Optional[Union[int, bool]] = None
    max_workers: Optional[int] = None

# -----------------------------------------------------------------------------
# Reader
# -----------------------------------------------------------------------------

class HyperCubeReader:
    """
    Reader for 4-D HyperCube models.

    Attributes
    ----------
    nSpat, nComp, nPop, nLSpec : int
        Dimensions of the HyperCube/models dataset.

    Notes
    -----
    - On-disk dtype can be float32; arrays are promoted to cfg.dtype
      (float64 by default) when returned.
    - If /DataCube is present, y is returned as cfg.dtype as well.
    - Legacy cfg fields are accepted to preserve pipeline calls; they are
      currently not used by this simplified reader.
    """

    def __init__(self, zarr_path: str | Path, cfg: Optional[ReaderCfg] = None):
        self.cfg = cfg or ReaderCfg()
        zp = str(zarr_path)

        # Prefer v3; if it opens but /HyperCube/models missing, still try v2 for legacy-only stores.
        try:
            root_v3 = zarr.group(store=zp, zarr_format=3)
            if "HyperCube" in root_v3 and "models" in root_v3["HyperCube"]:
                self._root = root_v3
            else:
                # v3 opened but no models; try a v2 view for older layouts
                self._root = zarr.open_group(zp, mode="r")
        except Exception:
            self._root = zarr.open_group(zp, mode="r")
        # --- Bind models array (supports external v3 models store) ---
        if "HyperCube" not in self._root:
            raise RuntimeError("Missing group /HyperCube in base store.")

        hc = self._root["HyperCube"]
        man = getattr(hc, "attrs", {}).get("manifest", {}) or {}
        models_store = man.get("models_store", None)

        models = None

        # Prefer external models store if a pointer exists
        if models_store:
            try:
                # External store was written as v3; open v3 first, fall back to v2 just in case
                try:
                    models = zarr.group(store=str(models_store), zarr_format=3)["models"]
                except Exception:
                    models = zarr.open_group(str(models_store), mode="r")["models"]
                logger.log(f"[Reader] Using external models store: {models_store}")
            except Exception as e:
                logger.log(f"[Reader] External models open failed: {e} — falling back to inline.")

        # Inline fallback (works for legacy runs)
        if models is None:
            try:
                models = hc["models"]                     # v3 inline
            except Exception:
                try:
                    models = self._root["HyperCube/models"]  # v2 path syntax
                except Exception as e:
                    raise RuntimeError(
                        "Missing dataset /HyperCube/models and no usable "
                        "'models_store' pointer in /HyperCube attrs. "
                        "Run build_hypercube first."
                    ) from e

        self._models = models

        # Record authoritative dimensions from models
        self.nSpat, self.nComp, self.nPop, self.nLSpec = map(int, self._models.shape)

        # Helpful one-liner log
        is_v3_models = hasattr(self._models, "codecs")
        codecs = getattr(self._models, "codecs", None)
        logger.log(
            f"[Reader] HyperCube/models: dtype={self._models.dtype}, "
            f"shape={self._models.shape}, chunks={self._models.chunks}, "
            f"v3={is_v3_models}, codecs={codecs}"
        )

        # Optional observed data and spectral mask
        self._data = self._root.get("DataCube", None)   # (nSpat, nLSpec)
        if self._data is not None:
            if self._data.shape != (self.nSpat, self.nLSpec):
                raise RuntimeError(
                    "DataCube shape mismatch: got %s, expected (%d, %d)"
                    % (str(self._data.shape), self.nSpat, self.nLSpec)
                )

        self._mask = self._root.get(self.cfg.mask_key, None) \
                     if self.cfg.apply_mask else None
        if self._mask is not None:
            m = np.asarray(self._mask[:])
            if m.ndim != 1 or m.size != self.nLSpec:
                logger.log(
                    "[Reader] Ignoring mask with incompatible shape:",
                    m.shape
                )
                self._mask = None

        # Log a concise summary (and quietly note ignored legacy params)
        try:
            m_dtype = str(self._models.dtype)
        except Exception:
            m_dtype = "unknown"
        logger.log(
            "[Reader] models=%s dtype=%s -> %s; DataCube=%s; mask=%s"
            % (
                str(self._models.shape),
                m_dtype,
                self.cfg.dtype,
                "yes" if self._data is not None else "no",
                "yes" if self._mask is not None else "no",
            )
        )
        if any(v is not None for v in
               (self.cfg.c_tile, self.cfg.p_tile,
                self.cfg.max_rows_in_mem, self.cfg.prefetch,
                self.cfg.max_workers)):
            logger.log("[Reader] Note: c_tile/p_tile/max_rows_in_mem/"
                       "prefetch/max_workers are accepted but ignored "
                       "by this simplified reader.")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _coerce(self, a: np.ndarray) -> np.ndarray:
        """Cast to cfg.dtype and ensure C-order if requested."""
        dt = np.float64 if self.cfg.dtype == "float64" else np.dtype(self.cfg.dtype)
        out = np.asarray(a, dtype=dt, order="C")
        if self.cfg.ensure_c_contig and not out.flags["C_CONTIGUOUS"]:
            out = np.ascontiguousarray(out)
        return out

    def _maybe_mask_spec(self, a: np.ndarray) -> np.ndarray:
        """Apply spectral mask (1-D) along last axis if enabled."""
        if self._mask is None:
            return a
        m = np.asarray(self._mask, dtype=a.dtype, order="C")
        if m.shape[0] == a.shape[-1]:
            return a * m
        return a

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def read_aperture(self, i: int, flatten: Optional[bool] = None):
        """
        Read models (and y, if present) for aperture index i.

        Parameters
        ----------
        i : int
            Aperture index [0..nSpat-1].
        flatten : Optional[bool]
            If True  -> return A_T with shape (nComp*nPop, nLSpec).
            If False -> return A   with shape (nComp, nPop, nLSpec).
            If None  -> use cfg.flatten if set, else default True.

        Returns
        -------
        tuple
            If flatten=True:
                (i, A_T, y) where
                A_T : (nComp*nPop, nLSpec), cfg.dtype
                y   : (nLSpec), cfg.dtype or None
            If flatten=False:
                (i, A, y) where
                A   : (nComp, nPop, nLSpec), cfg.dtype
                y   : (nLSpec), cfg.dtype or None
        """
        if not (0 <= i < self.nSpat):
            raise IndexError(f"aperture index out of range: {i}")

        if flatten is None:
            flatten = True if self.cfg.flatten is None else bool(self.cfg.flatten)

        # (1, C, P, L) slice -> (C, P, L)
        slab = np.asarray(self._models[i:i + 1, :, :, :], order="C")
        if slab.size == 0:
            raise RuntimeError(
                f"/HyperCube/models slice is empty for i={i} "
                f"with shape {self._models.shape}"
            )
        A = np.squeeze(slab, axis=0)        # (C, P, L) on-disk dtype
        A = self._coerce(A)                 # cast to cfg.dtype
        A = self._maybe_mask_spec(A)

        y = None
        if self._data is not None:
            y = self._coerce(self._data[i, :])
            if self.cfg.apply_mask and self._mask is not None:
                mask = np.asarray(self._mask[:], dtype=y.dtype, order="C")
                if mask.shape[0] == y.shape[0]:
                    y = y * mask

        if not flatten:
            return i, A, y

        # Flatten (C,P,L) -> (C*P, L)
        A_T = A.reshape(self.nComp * self.nPop, self.nLSpec)
        return i, A_T, y

    def iter_apertures(self, indices: Iterable[int] | None = None, flatten: Optional[bool] = None):
        """
        Iterate over apertures, yielding (i, A_T or A, y) for each.

        Parameters
        ----------
        indices : iterable of int or None
            Specific indices to iterate. If None, iterates all 0..nSpat-1.
        flatten : Optional[bool]
            If None, uses cfg.flatten (or True by default).
        """
        if indices is None:
            indices = range(self.nSpat)
        for i in indices:
            yield self.read_aperture(i, flatten=flatten)
