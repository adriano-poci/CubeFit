"""
Parallel worker for one aperture.

Expects shared Zarr datasets passed by reference (memory‑mapped).
"""

from __future__ import annotations
from CubeFit.model_cube import ModelCube
from CubeFit.kaczmarz_solver import KaczmarzSolver


def process_aperture(
    idx: int,
    z_data,
    z_templates,
    z_losvd,
    tem_pix,
    obs_pix,
    solver_kwargs: dict,
):
    """Solve weights for aperture *idx*."""
    y = z_data[idx]
    los = z_losvd[idx]
    A = ModelCube(
        z_templates, los, obs_pix, obs_pix, skip_rebin=True
    ).convolve()
    solver = KaczmarzSolver(**solver_kwargs)
    x, residuals = solver.solve(A, y)
    return idx, x, residuals
