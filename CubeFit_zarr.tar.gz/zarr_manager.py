# -*- coding: utf-8 -*-
r"""
    zarr_manager.py
    Adriano Poci
    University of Oxford
    2025

    Platforms
    ---------
    Unix, Windows

    Synopsis
    --------
    Manages Zarr data storage for CubeFit pipeline, including creation, loading,
    and validation of large, chunked arrays (templates, data cube, LOSVD, weights).
    Supports buffered template grids for safe convolution.

    Authors
    -------
    Adriano Poci <adriano.poci@physics.ox.ac.uk>

History
-------
v1.0:   Initial Zarr design and validation. 2025
v1.1:   Support for full template grids and chunk management. 2025
"""

from __future__ import annotations

import os
import psutil
from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np
from tqdm import tqdm
import zarr, hashlib
from zarr.storage import LocalStore
from pathlib import Path

from CubeFit.model_cube import ModelCube
from CubeFit.logger import get_logger

logger = get_logger()


def _open_root_v3(path: str | Path) -> zarr.Group:
    """
    Always create/open a **Zarr v3** root. This must be used for the very
    first write so the directory is formatted as v3 (not v2).
    """
    return zarr.group(store=str(path), zarr_format=3)


# ------------------------------------------------------------------------------

def init_or_rebuild_hypercube(
    zarr_path: str,
    *,
    n_batches: int,
    batch_size: int,
    nComp: int,
    nPop: int,
    nLSpec: int,
    within_chunk: int,  # == spat_tile you'll write
    comp_chunk: int,    # == comp_tile you'll write
    pop_chunk: int,     # == pop_tile you'll write
    overwrite_if_mismatch: bool = True,
    logger=None,
) -> zarr.Array:
    """
    Ensure HyperCube/models exists with chunking aligned to your write slabs.

    models.shape  = (n_batches, batch_size, nComp, nPop, nLSpec)
    models.chunks = (1, within_chunk, comp_chunk, pop_chunk, nLSpec)

    Set within_chunk == spat_tile and comp_chunk == comp_tile in your writer.
    """
    zroot = zarr.group(store=str(zarr_path), zarr_format=3)
    hg = zroot.require_group("HyperCube")

    shape  = (int(n_batches), int(batch_size), int(nComp), int(nPop), int(nLSpec))
    chunks = (
        1,
        int(within_chunk),
        int(min(comp_chunk, nComp)),
        int(min(pop_chunk,  nPop)),
        int(nLSpec),
    )

    if "models" in hg:
        arr = hg["models"]
        mismatch = (
            tuple(arr.shape)  != shape or
            tuple(arr.chunks) != chunks or
            arr.dtype != np.float64 or
            arr.order != "C"
        )
        if mismatch and overwrite_if_mismatch:
            if logger:
                logger.log(
                    "[ZarrManager] Rebuilding HyperCube/models due to mismatch: "
                    f"shape {arr.shape}->{shape}, chunks {arr.chunks}->{chunks}, "
                    f"dtype {arr.dtype}, order {arr.order}"
                )
            del hg["models"]
        elif mismatch:
            raise ValueError(
                "Existing HyperCube/models has incompatible shape/chunks/dtype. "
                "Enable overwrite_if_mismatch or delete it."
            )

    if "models" not in hg:
        if logger:
            logger.log(
                "[ZarrManager] Creating HyperCube/models with "
                f"shape={shape}, chunks={chunks}, dtype=float64"
            )
        arr = hg.create_dataset(
            "models",
            shape=shape,
            chunks=chunks,
            dtype=np.float64,
            compressors=None,   # no compression for max throughput
            order="C",
            overwrite=False,
        )
    return arr

# ------------------------------------------------------------------------------

def _md_for_array_hash(arr):
    """
    Compact, JSON-friendly metadata for manifest: shape, dtype, short hashes
    of the first/last 5 elements by raw bytes. Stable across runs.
    """
    a = np.asarray(arr)
    shape = list(a.shape)
    dtype = str(a.dtype)
    if a.size > 0:
        first_bytes = a.ravel()[:5].tobytes()
        last_bytes  = a.ravel()[-5:].tobytes()
        first_hash = hashlib.md5(first_bytes).hexdigest()[:8]
        last_hash  = hashlib.md5(last_bytes).hexdigest()[:8]
    else:
        first_hash = last_hash = "0" * 8
    return {
        "shape": shape,
        "dtype": dtype,
        "first_hash": first_hash,
        "last_hash": last_hash,
    }

def _normalize_manifest(m):
    """
    Coerce a manifest (possibly from Zarr attrs) into a canonical, comparable
    form.
    """
    if m is None:
        return None
    m = dict(m)
    for k in ("apertures_per_batch", "n_batches", "nSpat",
              "nComp", "nPop", "nLSpec"):
        if k in m:
            m[k] = int(m[k])
    for k in ("tem_pix_md5", "obs_pix_md5", "manifest_version"):
        if k in m:
            m[k] = str(m[k])
    for sub in ("templates_fft", "rebin_matrix"):
        if sub in m and isinstance(m[sub], dict):
            d = dict(m[sub])
            if "shape" in d and not isinstance(d["shape"], list):
                d["shape"] = list(d["shape"])
            if "dtype" in d:
                d["dtype"] = str(d["dtype"])
            for s in ("first", "last", "first_hash", "last_hash"):
                if s in d:
                    d[s] = str(d[s])
            m[sub] = d
    return m

def _manifests_equivalent(a, b):
    """
    Decide if two manifests describe the same HyperCube content, ignoring
    cosmetic sample/hash fields. Compares sizes, wavelength hashes, and
    shape/dtype of templates_fft & rebin_matrix.
    """
    if a is None or b is None:
        return False
    for k in ("apertures_per_batch", "n_batches", "nSpat",
              "nComp", "nPop", "nLSpec"):
        if int(a.get(k, -1)) != int(b.get(k, -1)):
            return False
    for k in ("tem_pix_md5", "obs_pix_md5"):
        if str(a.get(k, "")) != str(b.get(k, "")):
            return False

    def _shape_dtype(md):
        if not isinstance(md, dict):
            return None
        shp = md.get("shape")
        dt  = md.get("dtype")
        shp_t = tuple(shp) if isinstance(shp, (list, tuple)) else None
        dt_s  = str(dt) if dt is not None else None
        return (shp_t, dt_s)

    for sub in ("templates_fft", "rebin_matrix"):
        if _shape_dtype(a.get(sub, {})) != _shape_dtype(b.get(sub, {})):
            return False
    return True

# ------------------------------------------------------------------------------

def _as_indexer_1d(x):
    """
    Return a 1-D indexer that never drops an axis:
    - slice -> slice
    - scalar/0-D/1-D -> 1-D int64 array (len >= 1)
    """
    if isinstance(x, slice):
        return x
    arr = np.asarray(x, dtype=np.int64)
    if arr.ndim == 0:
        arr = arr.reshape(1)        # turn scalar into length-1 array
    elif arr.ndim != 1:
        raise ValueError("Indexer must be 1-D.")
    if arr.size == 0:
        raise ValueError("Empty indexer would select no elements.")
    return arr

# ------------------------------------------------------------------------------

def _compute_and_store_batch(
    zarr_store: str,
    batch_idx: int,
    spat_indices: list[int],
    templates_fft: np.ndarray,   # (nPop, fft_size), complex128
    rebin_matrix: np.ndarray,    # (nLSpec, nTSpec), float64
    tem_pix: np.ndarray,         # (nTSpec,)
    obs_pix: np.ndarray,         # (nLSpec,) (parity)
    nComp: int,
    nPop: int,
    nVel: int,
    nLSpec: int,
    comp_tile: int = 1,          # align to models.chunks[2]
    spat_tile: int = 4,          # align to models.chunks[1]
    pop_tile:  int = 16,         # align to models.chunks[3]
) -> None:
    """
    Compute convolved+rebinned models for one batch and write into
    HyperCube/models with chunk-aligned slabs.

    models[batch_idx, within, comp, pop, lspec] -> float64
    """
    if not spat_indices:
        return

    zroot     = zarr.group(store=str(zarr_store), zarr_format=3)
    models    = zroot["HyperCube/models"]   # (n_batches,B,nComp,nPop,nLSpec)
    losvd_arr = zroot["LOSVD"]              # (nSpat,nVel,nComp)

    nTSpec   = int(tem_pix.size)
    fft_size = int(templates_fft.shape[1])

    if (nVel % 2) != 1:
        raise ValueError("nVel must be odd so that v=0 is centered.")
    required = nTSpec + nVel - 1
    if fft_size < required:
        raise ValueError(
            f"templates_fft length {fft_size} < required {required} "
            f"(nTSpec + nVel - 1); rebuild templates_fft."
        )

    # Centered linear-convolution slice
    start_idx = (nVel - 1) // 2
    end_idx   = start_idx + nTSpec

    # Rebin helper: (nTSpec,nLSpec) C-contiguous for batched matmul
    R_T = np.asarray(rebin_matrix.T, dtype=np.float64, order="C")

    total_A = len(spat_indices)
    # Tile apertures (aligned to models.chunks[1] == spat_tile)
    for a0 in range(0, total_A, spat_tile):
        a1 = min(a0 + spat_tile, total_A)
        A = a1 - a0
        within_indices = np.arange(a0, a1, dtype=np.int64)
        abs_ids = np.asarray(spat_indices[a0:a1], dtype=np.int64)

        # Load LOSVD for this aperture tile: (A,nVel,nComp)
        los_sel = losvd_arr.get_orthogonal_selection(
            (abs_ids, slice(None), slice(None))
        )
        losvd_tile = np.asarray(los_sel, dtype=np.float64, order="C")

        # FFT over velocity axis -> (A,nComp,fft_size)
        losvd_fft_all = np.fft.fft(losvd_tile.transpose(0, 2, 1),
            n=fft_size, axis=2)

        # Tile components (aligned to models.chunks[2] == comp_tile)
        for c0 in range(0, nComp, comp_tile):
            c1 = min(c0 + comp_tile, nComp)
            C = c1 - c0
            losvd_fft_tile = losvd_fft_all[:, c0:c1, :]   # (A,C,fft)

            # Tile populations (aligned to models.chunks[3] == pop_tile)
            for p0 in range(0, nPop, pop_tile):
                p1 = min(p0 + pop_tile, nPop)
                P = p1 - p0
                tmpl_tile = templates_fft[p0:p1]                   # (P,fft)

                # Freq multiply: (A,C,1,fft) * (1,1,P,fft) -> (A,C,P,fft)
                prod_freq_tile = (
                    losvd_fft_tile[:, :, np.newaxis, :] *
                    tmpl_tile[np.newaxis, np.newaxis, :, :]
                )
                # IFFT & centered slice: (A,C,P,nTSpec)
                conv_full = np.fft.ifft(prod_freq_tile, axis=3)
                conv_tile = conv_full.real[..., start_idx:end_idx]

                # Rebin via batched matmul: (A,C,P,nTSpec) @ (nTSpec,nLSpec)
                models_blk = np.matmul(conv_tile, R_T)             # (A,C,P,nLSpec)
                zroot = zarr.group(store=str(zarr_store), zarr_format=3)

                # Important: always re-bind to the ROOT array (not a view)
                models = zroot["HyperCube/models"]  # path must be exactly "/HyperCube/models"

                batch_sel = _as_indexer_1d(batch_idx)
                spat_sel  = _as_indexer_1d(within_indices)
                comp_sel  = slice(c0, c1)
                pop_sel   = slice(p0, p1)
                lsel      = slice(None)

                payload = np.asarray(models_blk, dtype=np.float64, order="C")

                def _log_state(prefix, arr):
                    try:
                        path = getattr(arr, "path", "<no-path>")
                        shape = getattr(arr, "shape", "<no-shape>")
                        ndim  = getattr(arr, "ndim", "<no-ndim>")
                    except Exception:
                        path = shape = ndim = "<unavail>"
                    logger.log(
                        f"[ZarrManager] {prefix} path={path}, ndim={ndim}, shape={shape}; "
                        f"batch_sel={np.asarray(batch_sel)}, spat_sel={np.asarray(spat_sel)[:8]}..., "
                        f"comp_sel={comp_sel}, pop_sel={pop_sel}, lspec_sel={lsel}; "
                        f"payload.shape={payload.shape}"
                    )

                try:
                    # Preferred: 5-D write
                    if models.ndim != 5:
                        _log_state("WARN: models.ndim != 5 before write", models)
                    models = zroot["HyperCube/models"]  # re-ensure root again
                    models.set_orthogonal_selection(
                        (batch_sel, spat_sel, comp_sel, pop_sel, lsel),
                        payload,
                    )
                except IndexError as e:
                    # If something upstream handed us a 4-D view, recover by re-opening root.
                    _log_state(f"IndexError caught: {e}", models)
                    models = zroot["HyperCube/models"]  # force root again
                    if models.ndim == 5:
                        # Try again once on the root (in case 'models' was a 4-D view)
                        models.set_orthogonal_selection(
                            (batch_sel, spat_sel, comp_sel, pop_sel, lsel),
                            payload,
                        )
                    elif models.ndim == 4:
                        # True 4-D dataset on disk — fallback to absolute spaxel indexing
                        abs_spat = np.asarray(spat_indices, dtype=np.int64)[np.asarray(spat_sel)]
                        logger.log("[ZarrManager] Fallback 4-D write using absolute spaxels.")
                        models.set_orthogonal_selection(
                            (abs_spat, comp_sel, pop_sel, lsel),
                            payload,
                        )
                    else:
                        raise RuntimeError(f"Unexpected models.ndim={models.ndim}") from e

# ------------------------------------------------------------------------------

class ZarrManager:
    """
    Parameters
    ----------
    root_dir   : str           Zarr directory
    nSpat     : int           number of spatial apertures
    nComp     : int           number of dynamical components
    nVel      : int           LOSVD velocity bins
    nPop      : int           flattened template count
    nLSpec  : int           observed spectral pixels
    nTSpec  : int           template spectral pixels
    """

    def __init__(
        self,
        root_dir: str,
        nSpat: int,
        nComp: int,
        nVel: int,
        nPop: int,
        nLSpec: int,
        nTSpec: int
    ) -> None:
        self.root_dir = root_dir
        self.nSpat = nSpat
        self.nLSpec = nLSpec
        self.nTSpec = nTSpec
        self.nVel = nVel
        self.nComp = nComp
        self.nPop = nPop
        self.z = self._init_zarr()

        # logger.log(
        #     f"ZarrManager initialized: {self.root_dir} "
        #     f"({self.nSpat} spat, {self.nLSpec} lspec, "
        #     f"{self.nTSpec} tspec, {self.nVel} vel, "
        #     f"{self.nComp} comp, {self.nPop} pop)"
        # )

    # --------------------------------------------------------------------------

    def _init_zarr(self) -> zarr.Group:
        """
        Create (or open) the Zarr hierarchy as **v3**.
        Ensures the root is v3 *before* any arrays are created so later code
        (e.g., HyperCube/models with ShardingCodec) can use v3-only features.
        """

        root_path = Path(self.root_dir)

        # IMPORTANT: this stamps the directory as **v3**.
        root = zarr.group(store=str(root_path), zarr_format=3)

        def _require_array(name, *, shape, chunks, dtype):
            """
            v3-compatible 'require_array' helper.
            If the array exists, verify shape/dtype; recreate if mismatched.
            """
            if name in root:
                arr = root[name]
                ok = (tuple(arr.shape) == tuple(shape)) and (str(arr.dtype) == str(dtype))
                if ok:
                    return arr
                # shape/dtype changed: drop and recreate
                del root[name]
            return root.create_array(name, shape=shape, chunks=chunks, dtype=str(dtype))

        # LOSVD kernels (S, V, C)
        _require_array(
            "LOSVD",
            shape=(self.nSpat, self.nVel, self.nComp),
            chunks=(
                int(min(32, self.nSpat)),
                int(self.nVel),
                int(min(16, self.nComp)),
            ),
            dtype="float64",
        )

        # Observed spectra (S, L)
        _require_array(
            "DataCube",
            shape=(self.nSpat, self.nLSpec),
            chunks=(int(min(32, self.nSpat)), int(self.nLSpec)),
            dtype="float64",
        )

        # Stellar population templates (P, Tspec)
        _require_array(
            "Templates",
            shape=(self.nPop, self.nTSpec),
            chunks=(int(min(32, self.nPop)), int(self.nTSpec)),
            dtype="float64",
        )

        # Global spectral mask (L)
        _require_array(
            "Mask",
            shape=(self.nLSpec,),
            chunks=(self.nLSpec,),
            dtype="bool",
        )

        # True global solution vector (1D: nComp*nPop)
        _require_array(
            "X_global",
            shape=(self.nComp * self.nPop,),
            chunks=(min(8192, self.nComp * self.nPop),),
            dtype="float64",
        )

        # Also ensure the HyperCube group exists for the builder
        root.require_group("HyperCube")

        try:
            logger.log(
                f"ZarrManager initialized (v3): {root_path} "
                f"(LOSVD={(self.nSpat, self.nVel, self.nComp)}, "
                f"DataCube={(self.nSpat, self.nLSpec)}, "
                f"Templates={(self.nPop, self.nTSpec)})"
            )
        except Exception:
            pass

        return root

    # --------------------------------------------------------------------------
    
    def load_data_from_arrays(
        self,
        data: np.ndarray,
        templates: np.ndarray,
        losvd: np.ndarray,
        tem_pix: np.ndarray,
        obs_pix: np.ndarray,
        mask: np.ndarray | None = None
    ) -> None:
        """
        Persist external arrays into Zarr.

        Parameters
        ----------
        data       : (nPix_obs, nSpat)   observed spectra
        templates  : (nPix_tem, nMetal, nAge, nAlpha)
        losvd      : (nSpat, nVel, nComp)
        tem_pix    : (nPix_tem,)
        obs_pix    : (nPix_obs,)
        mask       : (nPix_obs,) | None   optional spectral mask
        """
        nLSpec, nSpat = data.shape
        nTSpec, nMetal, nAge, nAlpha = templates.shape
        nPop = nMetal * nAge * nAlpha

        if nSpat != self.nSpat:
            raise ValueError(
                f"Data has {nSpat} spatial apertures; "
                f"Zarr expects {self.nSpat}."
            )
        if nLSpec != self.nLSpec:
            raise ValueError(
                f"Data pixels = {nLSpec}; obs_pix length = {self.nLSpec}."
            )
        if losvd.shape != (nSpat, self.nVel, self.nComp):
            raise ValueError(
                "LOSVD shape mismatch: got "
                f"{losvd.shape}, expected "
                f"({nSpat}, {self.nVel}, {self.nComp})."
            )
        if nPop != self.nPop:
            raise ValueError(
                f"Templates flatten to nPop = {nPop}; "
                f"Zarr configured for nPop = {self.nPop}."
            )
        if nTSpec != tem_pix.size:
            raise ValueError(
                f"`tem_pix` length ({tem_pix.size}) must equal first "
                f"axis of templates ({nTSpec})."
            )

        data = np.asarray(data, dtype=np.float64).T
        losvd = np.asarray(losvd, dtype=np.float64)
        templates = np.asarray(templates, dtype=np.float64)
        templates_flat = np.transpose(templates, (1, 2, 3, 0)).reshape(
            nPop, nTSpec
        )

        # SAFE writes – force plain ndarray (no mask, no subclass)
        self.z["DataCube"][:] = data
        self.z["LOSVD"][:] = losvd
        self.z["Templates"][:] = templates_flat
        # mask: shape (nLSpec,), boolean
        if mask is not None:
            self.z["Mask"][:] = mask
    
# ------------------------------------------------------------------------------