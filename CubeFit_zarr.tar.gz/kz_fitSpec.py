# -*- coding: utf-8 -*-
r"""
    kz_fitSpec.py
    Adriano Poci
    University of Oxford
    2025

    Platforms
    ---------
    Unix, Windows

    Synopsis
    --------
    Master script to prepare data products and execute the workflow of CubeFit.

    Authors
    -------
    Adriano Poci <adriano.poci@physics.ox.ac.uk>

History
-------
v1.0:   2025
v1.1:   Read `zarrDir` from `kwargs` instead of hardcoding it. 12 August 2025
"""
# need to set up the logger before any other imports
import pathlib as plp
from CubeFit.logger import get_logger
print("[CubeFit] Initializing CubeFit logger...")
curdir = plp.Path(__file__).parent
lfn = curdir/'kz_run.log'
logger = get_logger(lfn, mode='w')
logger.log(f"[CubeFit] CubeFit logger initialised to {logger.logfile}",
    flush=True)

import os, pdb
import numpy as np
from tqdm import tqdm
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.patheffects as PathEffects
from matplotlib.colors import Normalize
from copy import copy
import zarr
from concurrent.futures import ProcessPoolExecutor, as_completed
from typing import Tuple, Sequence
from plotbin.display_pixels import display_pixels as dbi

from CubeFit.zarr_manager import ZarrManager
from CubeFit.pipeline_runner import PipelineRunner
from CubeFit.model_cube import ModelCube
from CubeFit.plotting import plot_aperture_fit, plot_white_light_images
from CubeFit.hypercube_builder import build_hypercube
from muse import tri_fitSpec as tf
from muse import tri_utils as uu
from dynamics.IFU.Constants import Constants, Units, UnitStr
from dynamics.IFU.Functions import Plot, Geometric

mDir = curdir.parent/'muse'
dDir = uu._ddir()

UTS = UnitStr()
UTT = Units()
CTS = Constants()
POT = Plot()
GEO = Geometric()

divcmap = 'GECKOSdr'
moncmap = 'inferno'
moncmapr = 'inferno_r'

# ------------------------------------------------------------------------------

def genCubeFit(galaxy, mPath, decDir=None, nCuts=None, proj='i', SN=90,
    full=False, slope=1.30, IMF='KB', iso='pad', weighting='luminosity',
    nProcs=1, lOrder=4, rescale=False, specRange=None, lsf=False,
    band='r', smask=None, method='fsf', varIMF=False,
    source='ppxf', **kwargs):
    """
    _summary_

    Parameters
    ----------
    galaxy : str
        Name of the galaxy to process.
    mPath : str
        Path to the model directory.
    decDir : str, optional
        Decomposition directory name, by default None.
    nCuts : int, optional
        Number of cuts for decomposition, by default None.
    proj : str, optional
        Projection type, by default 'i'.
    SN : int, optional
        Signal-to-noise ratio, by default 90.
    full : bool, optional
        Whether to use full data or truncated, by default False.
    slope : float, optional
        Slope for the IMF, by default 1.30.
    IMF : str, optional
        Initial mass function type, by default 'KB'.
    iso : str, optional
        Isochrones type, by default 'pad'.
    weighting : str, optional
        Weighting scheme, by default 'luminosity'.
    nProcs : int, optional
        Number of processes to use, by default 1.
    lOrder : int, optional
        Polynomial order for the fit, by default 4.
    fit : str, optional
        Type of fit to perform, by default 'cube'.
    rescale : bool, optional
        Whether to rescale the data, by default False.
    specRange : tuple, optional
        Spectral range to consider, by default None.
    lsf : bool, optional
        Whether to apply LSF (Line Spread Function), by default False.
    band : str, optional
        Band to use for the fit, by default 'r'.
    smask : str, optional
        Mask for the spectra, by default None.
    method : str, optional
        Method to use for the fit, by default 'fsf'.
    varIMF : bool, optional
        Whether to use variable IMF, by default False.
    source : str, optional
        Source of the data, by default 'ppxf'.
    **kwargs : dict, optional
        Additional keyword arguments for the function.
    """

    # Directories
    bDir = mDir/'tri_models'/mPath
    pDir = curdir.parent/'pxf'
    spDir = bDir/'SPDec'
    MKDIRS = [bDir, pDir, spDir]
    [plp.Path(DIR).mkdir(parents=True, exist_ok=True) for DIR in MKDIRS]
    if isinstance(decDir, type(None)):
        with open(bDir/'decomp.dir', 'r+') as dd:
            decDir = dd.readline().strip()
    if isinstance(nCuts, type(None)):
        direc = list(filter(lambda xd: xd.is_dir(),
            (bDir/decDir).glob('decomp_*')))[0]
    else:
        direc = bDir/decDir/f"decomp_{nCuts:d}"
    if 'fif' in method:
        IMF = 'FIF'
        iso = 'fif'
    if not full:
        tEnd = 'trunc'
    else:
        tEnd = 'full'
    w8Str = f"{weighting[0].upper()}W"
    tag = f"_SN{int(SN):02d}_{iso}_{IMF}{slope:.2f}_{w8Str}"

    # Filenames
    infn = bDir/'infil.xz'
    INF = uu.Load.lzma(infn)

    cont = kwargs.pop('cont', False)

    with logger.capture_all_output():
        decDir, cDirs, cKeys, nComp, teLL, lnGrid, histBinSize, dataVelScale,\
            RZ, spLL, laGrid, lmin, lmax, umetals, uages, ualphas, pixOff = \
            tf._oneTimeSpec(galaxy=galaxy, mPath=mPath, decDir=decDir,
            nCuts=nCuts, proj=proj, SN=SN, full=full, slope=slope, IMF=IMF,
            iso=iso, weighting=weighting, lOrder=lOrder, rescale=rescale,
            lsf=lsf, specRange=specRange, band=band, method=method,
            varIMF=varIMF, source=source, **kwargs)
    nLSpec, nSpat = laGrid.shape
    nTSpec, nMetals, nAges, nAlphas = lnGrid.shape
    nSSP = int(np.prod((nMetals, nAges, nAlphas), dtype=int))
    pred = f"0{len(repr(nComp)):d}"
    nComp = int(nComp)
    afDir = spDir/'apers'/f"C{nComp:04d}"
    sfDir = spDir/'SSPFit'/f"C{nComp:04d}"
    MKDIRS = [afDir, sfDir]
    [DIR.mkdir(parents=True, exist_ok=True) for DIR in MKDIRS]
    lAPF = "{}_{}_c.npy"
    globAper = afDir.rglob(lAPF.format('*', f"{lOrder:02}"))
    runAper = np.arange(nSpat)

    oDict = uu.Load.lzma(direc/f"decomp_{nCuts:d}.plt")
    if 'binFN' not in oDict.keys():
        oDict['binFN'] = 'bins_0.dat'
        oDict['apFN'] = 'aperture_0.dat'
        uu.Write.lzma(direc/f"decomp_{nCuts:d}.plt", oDict)
    binFN = oDict['binFN']
    apFN = oDict['apFN']
    dnPix, dgrid = uu.Read.bins(bDir/'infil'/binFN)
    dnbins = int(np.max(dgrid))
    dgrid -= 1
    dss = np.where(dgrid >= 0)[0]
    dx0, dx1, dnx, dy0, dy1, dny, dtheta = uu.Read.aperture(
        bDir/'infil'/apFN)
    ddx = np.abs((dx1-dx0)/dnx)
    ddy = np.abs((dy1-dy0)/dny)
    dpixs = np.min([ddx, ddy])
    dxr = np.arange(dnx)*dpixs + dx0 + 0.5*dpixs
    dyr = np.arange(dny)*dpixs + dy0 + 0.5*dpixs
    dxtss = uu._hash(dxr, np.full_like(dyr, 1)).ravel()[dss]
    dytss = uu._hash(np.full_like(dxr, 1), dyr).ravel()[dss]
    dtestX, dtestY = GEO.rotate2D(dxtss, dytss, dtheta)
    duPix, dpInverse, dpCounts = np.unique(dgrid[dss], return_inverse=True,
        return_counts=True)
    dpCount = dpCounts[dpInverse]

    biI = INF['bins'][0]
    bCount = biI['pCountsBin']
    # grid = np.array(biI['grid'], dtype=int).ravel()-1
    grid = np.array(biI['grid'], dtype=int).T.ravel()-1
    nbins = np.max(grid).astype(int)+1
    ss = np.where(grid >= 0)[0]

    if np.max(dpCount) > 1: # at least one bin contains more than one pixel
        # a quick way to check if the oberved scheme was used
        dgrid = grid
        dss = ss
        dnbins = nbins
        dpCount = bCount

    nzComp = np.array(oDict['nzComp'], dtype=int)
    nnOrb = plp.Path(*oDict['nnOrb'])
    oClass = plp.Path(*oDict['oClass'])
    obClass = plp.Path(*oDict['obClass'])
    bLKey = uu.keySep.join([nnOrb.parent.parent.name, nnOrb.parent.name])
    bLKey = uu.rReplace(bLKey, uu.keySep, os.sep, 1)
    nnOrb = plp.Path(bDir, decDir, nnOrb.parent.name, nnOrb.name)
    oClass = plp.Path(bDir, decDir, oClass.parent.name, oClass.name)
    obClass = plp.Path(bDir, decDir, obClass.parent.name, obClass.name)
    fpd = uu._deetExtr(bLKey)
    apDir = bDir/bLKey/'nn_aphist.out'
    maDir = (bDir/bLKey).parent/'datfil'/'mass_aper.dat'
    nnK = bDir/bLKey/'nn_kinem.out'

    NOrbs, inds, energs, I2s, I3s, regs, types, weights, lcuts =\
        uu.Read.orbits(nnOrb)
    cWeights = np.zeros(nComp)
    for jk, comp in enumerate(nzComp):
        cWeights[jk] = np.ma.sum(weights[oDict['wheres'][f"{comp:{pred}d}"]])

    kiBin = INF['kin']['nbins'][0]
    assert nbins == kiBin, 'Output does not agree with input bins\nInput:'+\
        f"{kiBin}\nOutput: {nbins}"

    wbin, hN, histBinSize, hArr = uu.Read.apertureHist(apDir)
    logger.log(f"{'Mass outside of the histograms:': <45s}"\
          f"{np.sum(hArr[:, 0] + hArr[:, wbin * 2]):5.5}")

    fullBin, fullID, fullK0 = uu.Read.massAperture(maDir)
    logger.log(f"{'Mass normalisation is:': <45s}"\
        f"{np.sum(hArr) / np.sum(fullK0):5.5}")
    if isinstance(proj, list):
        pStr = ''.join([str(f) for f in proj])
    else:
        pStr = str(proj)
    plt.close('all')
    massNorm = fullK0

    apMassFile = direc/f"apMass_i{proj}_{nComp:{pred}d}.xz"
    if apMassFile.is_file():
        aperMass = uu.Load.lzma(apMassFile)
    else:
        aperMass = np.ma.ones((nSpat, nComp), dtype=float)*np.nan
        ERR = []
        for cn, cDir in tqdm(enumerate(cDirs), desc='Mass', total=nComp):
            try:
                maFile = cDir/'declib_apermass.out'
                nbin, ID, k0 = uu.Read.massAperture(maFile)
                aperMass[:, cn] = k0
            except:
                ERR += [cDir.name]
        if len(ERR) > 0:
            logger.log(ERR)
            breakpoint()
        uu.Write.lzma(apMassFile, aperMass)
    aperMass = np.ma.masked_invalid(aperMass)
    norma = np.sum(aperMass, axis=1)

    logger.log('Done.', flush=True)
    apFile = cDirs[0]/'declib_aphist.out'
    wbin, hN, histBinSize, hArr = uu.Read.apertureHist(apFile)
    # Load the parameters regardless
    apHistFile = direc/f"apHists_i{pStr}_{nComp:{pred}d}.jl"
    if apHistFile.is_file():
        logger.log('Reading histograms...', flush=True)
        apHists = uu.Load.jobl(apHistFile)
    else:
        apFile = cDirs[0]/'declib_aphist.out'
        wbin, hN, histBinSize, cArr = uu.Read.apertureHist(apFile)
        logger.log('Generating histograms...', flush=True)
        apHists = np.ma.ones((*cArr.shape, nComp))*np.nan
        ERR = []
        for cn, cDir in tqdm(enumerate(cDirs), desc='Components',
            total=nComp):
            try:
                apFile = cDir/'declib_aphist.out'
                wbin, hN, histBinSize, cArr = uu.Read.apertureHist(
                    apFile)
                apHists[:, :, cn] = cArr
            except:
                ERR += [cDir.stem]
        if len(ERR) > 0:
            logger.log(ERR)
            pdb.set_trace()
        uu.Write.jobw(apHistFile, apHists)
    logger.log('Done.')
    apHists = np.ma.masked_invalid(apHists)
    nApHists = (apHists*(massNorm/norma)[:, np.newaxis, np.newaxis])
    # (nSpat, nVel, nComp)

    logger.log('Generating spectral mask...', flush=True)
    spmask = np.ones(nLSpec, dtype=bool)
    with open(dDir/'emissionLines.txt', 'r+') as emlf:
        emMask = np.genfromtxt(emlf, usecols=(0, 1))
    for emm in emMask:
        smask += [[emm[0]-emm[1]/2.0, emm[0]+emm[1]/2.0]]
    if len(smask)>0:
        for pair in smask:
            spmask[(spLL>=np.log(pair[0])) & (spLL<=np.log(pair[1]))] = False
    logger.log('Done.', flush=True)

    # _, _, KIN, _ = uu.Read.kinematics(nnK)
    # chi2 = np.sum([(KIN[2+(xz*3), :]-KIN[2+(xz*3)+1, :])/KIN[2+(xz*3)+2, :] for
    #     xz in range(kwargs.pop('nMom', 4))], axis=0)

    ## Down-selection of apertures
    # test_N_spat = min(nSpat, 32)   # or whatever small N you want for test
    # rng = np.random.default_rng(42)
    # indices = np.linspace(0, nSpat-1, test_N_spat, dtype=int)
    # indices = np.sort(indices)  # optional: keep order
    # print(f"[CubeFit TEST] Using random {test_N_spat} of {nSpat} spatial apertures.")
    # # Apply to all spatial-dimensioned arrays
    # laGrid = laGrid[:, indices]               # (nLSpec, test_N_spat)
    # nApHists = nApHists[indices, :, :]        # (test_N_spat, nVel, nComp)
    # aperMass = aperMass[indices, :]           # (test_N_spat, nComp)
    # norma = norma[indices]                    # (test_N_spat,)
    # # ... any other arrays with nSpat axis ...
    # nSpat = test_N_spat                       # update for the rest of workflow


    # --- Setup Zarr directory ---
    zarrDir = kwargs.pop('zarrDir', curdir/f"{galaxy}_{lOrder:02d}")
    zarrDir.mkdir(parents=True, exist_ok=True)

    # --- Initialize and load data ---
    nVel = hArr.shape[-1]

    logger.log("[CubeFit] Initializing ZarrManager...")
    with logger.capture_all_output():
        try:
            zmgr = ZarrManager(zarrDir, nSpat, nComp, nVel, nSSP, nLSpec,
                nTSpec)
            zmgr.load_data_from_arrays(laGrid, lnGrid, nApHists,
                tem_pix=copy(teLL), obs_pix=copy(spLL), mask=spmask,)
        except Exception as e:
            logger.log(f"[CubeFit] ZarrManager initialization failed: {e}")
            raise e
    logger.log("[CubeFit] Data stored.")

    # --- Run solver ---
    logger.log("[CubeFit] Initializing PipelineRunner...")
    with logger.capture_all_output():
        try:
            runner = PipelineRunner(zarrDir, nSpat, nComp, nVel, nSSP, nLSpec,
                nTSpec, tem_pix=copy(teLL), obs_pix=copy(spLL), lOrder=lOrder)
        except Exception as e:
            logger.log(f"[CubeFit] PipelineRunner initialization failed: {e}")
            raise e
    logger.log("[CubeFit] PipelineRunner initialised.")

    runner.zarr_path = zarrDir

    batch_size = kwargs.pop('batch_size', 32)

    # --- 2. Precompute HyperCube ---
    with logger.capture_all_output():
        build_hypercube(
            zarrDir,
            nSpat=nSpat, nComp=nComp, nPop=nSSP, nLSpec=nLSpec,
            S=16, C=1, P=256,
            shard_S=128, shard_C=23, shard_P=128, # ≈520 MiB/shard, ~1.2k files
            templates_fft=runner.templates_fft,
            rebin_matrix=runner.rebin_matrix,
            tem_pix=runner.tem_pix, obs_pix=runner.obs_pix,
            n_workers=nProcs,
            mode="direct",
            check='auto'
        )


        # # Slow disks could use shards.
        # build_hypercube(
        #     zarrDir,
        #     nSpat=nSpat, nComp=nComp, nPop=nSSP, nLSpec=nLSpec,
        #     templates_fft=runner.templates_fft,
        #     rebin_matrix=runner.rebin_matrix,
        #     tem_pix=runner.tem_pix, obs_pix=runner.obs_pix,
        #     n_workers=nProcs,
        #     mode="sharded",
        #     shard_dir=zarrDir/"HyperCube"/"shards",
        # )

    ## Run convolution tests
    # p = 0  # template index
    # c = 1  # kernel/component index
    # s = 0  # spatial aperture index (for testing)
    # plot_dir = os.path.join(zmgr.root_dir, "plots")
    # offset = ModelCube.test_convolution_pixel_offset(
    #     runner.z["Templates"][p], runner.z["LOSVD"][:][s, :, c], runner.tem_pix,
    #     runner.obs_pix, plot=True, plot_dir=plot_dir, tag=f"s{s}_c{c}_p{p}")
    # print(f"Measured convolution/rebin pixel offset: {offset:.3f}")
    
    # --- Run the fit (global, tiled) ---
    logger.log("[CubeFit] Running the global fit (tiled, true-prior)...")
    with logger.capture_all_output():
        x_global, residuals = runner.solve_all(
            global_fit=True,
            mode="full",
            epochs=1, # passes over all apertures
            pixels_per_aperture=256, # stochastic Kaczmarz pixels per aperture
            max_rows_in_mem=8192, # rows per tile = C_tile*P_tile cap
            reader_prefetch=8, # small read-ahead
            reader_workers=min(4, nProcs),

            # solver
            lr=0.25,
            project_nonneg=True, # kept for API compat; NN enforced inside

            # TRUE PRIOR (per-component vector, shape = (nComp,))
            orbit_weights=cWeights,
            verbose=True,

            # where the Zarr lives
            zarr_path=zarrDir,
            # spaxel_indices=...        # optional subset
        )
    logger.log("[CubeFit] Global fit completed.")
    logger.log(f"{x_global}")
    zmgr.z['X_global'][:] = x_global

    # --- Save the fit results ---
    logger.log("[CubeFit] Saving fit results...")
    with logger.capture_all_output():
        try:
            CUBE = parallel_model_cube_global_batched(zmgr.z, x_global, nSpat,
                nLSpec, n_workers=nProcs)
        except Exception as e:
            logger.log(f"[CubeFit] Saving fit results failed: {e}")
            raise e
    logger.log("[CubeFit] ModelCube computed and saved.")

# ------------------------------------------------------------------------------

def compute_model_batch_global(
    zarr_store,
    batch_idx: int,
    x_global: np.ndarray,
    nSpat: int,
) -> Tuple[int, np.ndarray]:
    """
    Reconstruct all model spectra for a given HyperCube batch in one go.

    Parameters
    ----------
    zarr_store : zarr storage or path
        Store (e.g., DirectoryStore) used to open the Zarr group inside worker.
    batch_idx : int
        HyperCube batch index (0..n_batches-1).
    x_global : ndarray, shape (nComp*nPop,) or (nComp, nPop)
        True-global weights (float64 preferred).
    nSpat : int
        Total number of spatial apertures; used to clip last partial batch.

    Returns
    -------
    (start, Y) : (int, ndarray (m, nLSpec))
        `start` is the absolute starting aperture id for this batch:
            start = batch_idx * B
        `Y` are the reconstructed spectra for apertures [start, start+m),
        where m = min(B, nSpat - start).
    """
    zroot = zarr.group(str(zarr_store), zarr_format=3)
    models = zroot["HyperCube/models"]  # (n_batches, B, nComp, nPop, nLSpec)
    n_batches, B, nComp, nPop, nLSpec = models.shape

    # Work out this batch’s absolute span
    start = batch_idx * B
    if start >= nSpat:
        return start, np.empty((0, nLSpec), dtype=np.float64)
    m = int(min(B, nSpat - start))

    # Load basis for the m apertures: (m, nComp, nPop, nLSpec)
    mb = models.get_orthogonal_selection(
        (np.asarray([batch_idx], np.int64),
         np.arange(m, dtype=np.int64),
         slice(None), slice(None), slice(None))
    )[0]
    mb = np.asarray(mb, dtype=np.float64, order="C")

    # Global weights as (nComp, nPop)
    xB = (x_global.reshape(nComp, nPop)
          if x_global.ndim == 1 else x_global).astype(np.float64, copy=False)

    # Vectorized combination across components and populations:
    # Y[m, p] = sum_{c,k} mb[m, c, k, p] * xB[c, k]
    Y = np.einsum('mckp,ck->mp', mb, xB, optimize=True)

    return start, Y

# ------------------------------------------------------------------------------

def _reconstruct_spaxel_range(zarr_path: str, array_name: str,
                                s0: int, s1: int, x_cp_2d) -> tuple[int, int]:
    import numpy as _np, zarr as _zarr
    zloc = _zarr.group(str(zarr_path), zarr_format=3)
    models_loc = zloc["HyperCube/models"]
    out_loc = zloc[array_name]
    if models_loc.ndim == 4:
        slab = _np.asarray(models_loc[s0:s1, :, :, :], order="C")
        Y = _np.tensordot(slab, x_cp_2d, axes=([1, 2], [0, 1]))
    else:
        Y = _np.empty((s1 - s0, out_loc.shape[1]), dtype=_np.float64)
        for s in range(s0, s1):
            b, i = divmod(s, models_loc.shape[1])
            spec = _np.asarray(models_loc[b, i, :, :, :], order="C")
            Y[s - s0, :] = _np.tensordot(
                spec, x_cp_2d, axes=([0, 1], [0, 1])
            )
    if Y.dtype != _np.float64:
        Y = Y.astype(_np.float64, copy=False)
    if not Y.flags["C_CONTIGUOUS"]:
        Y = _np.ascontiguousarray(Y)
    out_loc[s0:s1, :] = Y
    return (s0, s1)

# ------------------------------------------------------------------------------

def parallel_model_cube_global_batched(
    z,
    x_global,
    nSpat: int,
    nLSpec: int,
    n_workers: int = 1,
    array_name: str = "ModelCube",
    spat_tile: int | None = None,
):
    """
    Vectorized reconstruction of the full model cube from one global x.

    Writes an on-disk (nSpat, nLSpec) array named `array_name`.
    Parallelizes over spaxel ranges; single-process path never needs a
    filesystem path and operates directly on `z`.
    """

    # ---- helper: try to resolve a filesystem path for multi-process ----
    def _resolve_store_path(zgrp) -> str | None:
        s = getattr(zgrp, "store", None)
        if s is None:
            return None
        # Common attributes various stores expose
        for attr in ("path", "dir_path", "base_path", "_path", "_dir_path"):
            p = getattr(s, attr, None)
            if isinstance(p, (str, bytes)) or hasattr(p, "__fspath__"):
                return str(p)
        # FSStore has .root; try that
        root = getattr(s, "root", None)
        if isinstance(root, (str, bytes)) or hasattr(root, "__fspath__"):
            return str(root)
        return None

    models = z["HyperCube/models"]
    if models.ndim == 4:
        S_disk, C_disk, P_disk, L_disk = models.shape
        assert S_disk == nSpat, f"S mismatch: {S_disk} vs {nSpat}"
        assert L_disk == nLSpec, f"L mismatch: {L_disk} vs {nLSpec}"
    elif models.ndim == 5:
        nB, B, C_disk, P_disk, L_disk = models.shape
        assert nB * B == nSpat, f"S mismatch: {nB*B} vs {nSpat}"
        assert L_disk == nLSpec, f"L mismatch: {L_disk} vs {nLSpec}"
    else:
        raise RuntimeError(f"Unexpected HyperCube/models rank: {models.ndim}")

    # x -> (C,P)
    x_arr = np.asarray(x_global, dtype=np.float64)
    if x_arr.ndim == 1:
        assert x_arr.size == C_disk * P_disk, \
            f"x size {x_arr.size} != C*P {C_disk*P_disk}"
        x_cp = x_arr.reshape(C_disk, P_disk)
    elif x_arr.ndim == 2:
        assert x_arr.shape == (C_disk, P_disk), \
            f"x shape {x_arr.shape} != (C={C_disk}, P={P_disk})"
        x_cp = x_arr
    else:
        raise ValueError("x_global must be 1-D or 2-D (C,P).")

    # Destination (row-major spectral chunks)
    out = z.require_dataset(
        array_name,
        shape=(nSpat, nLSpec),
        chunks=(min(64, nSpat), nLSpec),
        dtype="f8",
        compressor=None,
        overwrite=False,
        order="C",
    )

    # Plan tiles
    if spat_tile is None:
        s_chunk = models.chunks[0] if hasattr(models, "chunks") else 32
        spat_tile = max(s_chunk * 4, 1)

    def _tiles(n: int, step: int):
        i = 0
        while i < n:
            j = min(i + step, n)
            yield i, j
            i = j

    ranges = list(_tiles(nSpat, spat_tile))
    logger.log(
        "[Reconstruct] %d spaxels, L=%d, C=%d, P=%d; tiles=%d; workers=%d"
        % (nSpat, nLSpec, C_disk, P_disk, len(ranges), n_workers)
    )

    # ---- single-process path (no filesystem path needed) ----
    if n_workers <= 1:
        for s0, s1 in tqdm(ranges, desc="[Reconstruct] tiles"):
            if models.ndim == 4:
                slab = np.asarray(models[s0:s1, :, :, :], order="C")
                Y = np.tensordot(slab, x_cp, axes=([1, 2], [0, 1]))
            else:
                # legacy 5-D: (nB, B, C, P, L)
                Y = np.empty((s1 - s0, nLSpec), dtype=np.float64)
                for s in range(s0, s1):
                    b, i = divmod(s, models.shape[1])
                    spec = np.asarray(models[b, i, :, :, :], order="C")
                    Y[s - s0, :] = np.tensordot(
                        spec, x_cp, axes=([0, 1], [0, 1])
                    )
            if Y.dtype != np.float64:
                Y = Y.astype(np.float64, copy=False)
            if not Y.flags["C_CONTIGUOUS"]:
                Y = np.ascontiguousarray(Y)
            out[s0:s1, :] = Y
        logger.log("[Reconstruct] Done (single-process).")
        return

    # ---- multi-process path (requires filesystem path) ----
    zroot_path = _resolve_store_path(z)
    if zroot_path is None:
        logger.log(
            "[Reconstruct] Could not resolve a filesystem path for the Zarr "
            "store; falling back to single-process."
        )
        for s0, s1 in tqdm(ranges, desc="[Reconstruct] tiles"):
            if models.ndim == 4:
                slab = np.asarray(models[s0:s1, :, :, :], order="C")
                Y = np.tensordot(slab, x_cp, axes=([1, 2], [0, 1]))
            else:
                Y = np.empty((s1 - s0, nLSpec), dtype=np.float64)
                for s in range(s0, s1):
                    b, i = divmod(s, models.shape[1])
                    spec = np.asarray(models[b, i, :, :, :], order="C")
                    Y[s - s0, :] = np.tensordot(
                        spec, x_cp, axes=([0, 1], [0, 1])
                    )
            if Y.dtype != np.float64:
                Y = Y.astype(np.float64, copy=False)
            if not Y.flags["C_CONTIGUOUS"]:
                Y = np.ascontiguousarray(Y)
            out[s0:s1, :] = Y
        logger.log("[Reconstruct] Done (fallback single-process).")
        return

    with ProcessPoolExecutor(max_workers=n_workers) as pool:
        futs = [
            pool.submit(_reconstruct_spaxel_range, zroot_path,
                        array_name, s0, s1, x_cp)
            for (s0, s1) in ranges
        ]
        for fut in tqdm(as_completed(futs), total=len(futs),
                        desc="[Reconstruct] tiles"):
            fut.result()
    logger.log("[Reconstruct] Done (multi-process).")
    return out  # <-- return the dataset handle

# ------------------------------------------------------------------------------

def save_spectrum_plot(s, y_obs, y_mod, obs_pix, chi2, plot_dir, tag, mask):
    """Save spectrum fit + residual panel for aperture s."""
    plt.figure()
    plot_aperture_fit(y_obs, y_mod, obs_pix, aperture_index=s, mask=mask,)
    fname = os.path.join(plot_dir, f"spectrum_fit_{tag}_ap{s:04d}.png")
    plt.savefig(fname, dpi=150)
    plt.close()
    return fname

# ------------------------------------------------------------------------------

def parallel_spectrum_plots(
    z,
    model_spectra: np.ndarray,
    obs_pix: np.ndarray,
    chi2: np.ndarray,
    n: int = 10,
    plot_dir: str = "plots",
    n_workers: int = 8,
    tag: str = "",
    mask: np.ndarray | None = None,
):
    """
    Save N worst/best spectrum fits in parallel with a progress bar.

    Parameters
    ----------
    z : zarr.Group
        Must contain 'DataCube'. 'Mask' optional if `mask` not provided.
    model_spectra : (nSpat, nLSpec) ndarray
        Reconstructed model cube (or a view of it).
    obs_pix : (nLSpec,) ndarray
        Wavelength axis for plotting (e.g., np.exp(spLL)).
    chi2 : (nSpat,) ndarray
        Fit quality per aperture; used to pick best/worst.
    n : int
        How many best and worst spectra to save (each).
    plot_dir : str
        Output directory.
    n_workers : int
        Number of processes for saving plots.
    tag : str
        Identifier appended to filenames.
    mask : (nLSpec,) bool or None
        Spectral mask to display (defaults to z['Mask'] if present).
    """
    os.makedirs(plot_dir, exist_ok=True)

    # Pick worst/best indices
    idx_worst = np.argsort(chi2)[-n:]
    idx_best = np.argsort(chi2)[:n]

    # Resolve mask if not provided
    if mask is None and "Mask" in z:
        mask = z["Mask"][:]

    # Build jobs: (s, y_obs, y_mod, obs_pix, chi2[s], plot_dir, tag, mask)
    jobs = []
    for s in idx_worst:
        jobs.append((s, z["DataCube"][s], model_spectra[s], obs_pix,
                     chi2[s], plot_dir, f"worst_{tag}", mask))
    for s in idx_best:
        jobs.append((s, z["DataCube"][s], model_spectra[s], obs_pix,
                     chi2[s], plot_dir, f"best_{tag}", mask))

    with ProcessPoolExecutor(max_workers=n_workers) as pool:
        futures = [
            pool.submit(save_spectrum_plot, *args) for args in jobs
        ]
        for fut in tqdm(as_completed(futures), total=len(futures),
                        desc="Spec plots", ncols=80):
            try:
                print(f"[Plot] Saved: {fut.result()}")
            except Exception as e:
                print(f"[Plot] ERROR: {e}")

# ------------------------------------------------------------------------------

def make_white_light(data_cube, model_cube, plot_dir):
    """Save white-light summary images (serial; not needed in pool)."""
    plot_white_light_images(
        data_cube,
        model_cube,
        save_path=os.path.join(plot_dir, "white_light_images.png"),
    )
    print(f"[Plot] White-light summary saved to {plot_dir}")

# ------------------------------------------------------------------------------

def save_cube_to_zarr(z, CUBE, nSpat, nLSpec):
    out = z.require_array(
        "ModelCube", shape=(nSpat, nLSpec),
        chunks=(min(32, nSpat), nLSpec), dtype="float64"
    )
    out[:] = CUBE

# ------------------------------------------------------------------------------

def is_cube_populated(z, key, nSpat, nLSpec):
    """Return True if key exists and has the expected shape, dtype, and not all zeros/NaN."""
    if key not in z:
        return False
    arr = z[key]
    if arr.shape != (nSpat, nLSpec):
        return False
    sample = arr[:10]
    if np.isnan(sample).any() or np.all(sample == 0):
        return False
    return True

# ------------------------------------------------------------------------------

def loadCubeFit(galaxy, mPath, decDir=None, nCuts=None, proj='i', SN=90,
    full=False, slope=1.30, IMF='KB', iso='pad', weighting='luminosity',
    nProcs=1, lOrder=4, rescale=False, specRange=None, lsf=False,
    band='r', smask=None, method='fsf', varIMF=False,
    source='ppxf', pplots=['spec', 'mw'], **kwargs):
    """
    Load the CubeFit data for a given galaxy and model path.
    """
    # Directories
    bDir = mDir/'tri_models'/mPath
    pDir = curdir.parent/'pxf'
    spDir = bDir/'SPDec'
    MKDIRS = [bDir, pDir, spDir]
    [plp.Path(DIR).mkdir(parents=True, exist_ok=True) for DIR in MKDIRS]
    if isinstance(decDir, type(None)):
        with open(bDir/'decomp.dir', 'r+') as dd:
            decDir = dd.readline().strip()
    if isinstance(nCuts, type(None)):
        direc = list(filter(lambda xd: xd.is_dir(),
            (bDir/decDir).glob('decomp_*')))[0]
    else:
        direc = bDir/decDir/f"decomp_{nCuts:d}"
    if 'fif' in method:
        IMF = 'FIF'
        iso = 'fif'
    if not full:
        tEnd = 'trunc'
    else:
        tEnd = 'full'
    w8Str = f"{weighting[0].upper()}W"
    tag = f"_SN{int(SN):02d}_{iso}_{IMF}{slope:.2f}_{w8Str}"

    pfs = pDir/galaxy/f"pixels_SN{SN:02d}.xz"
    vbSpec = pDir/galaxy/f"voronoi_SN{SN:02d}_{tEnd}.xz"
    infn = bDir/'infil.xz'

    INF = uu.Load.lzma(infn)
    PA = INF['angle'][0]
    if vbSpec.is_file():
        VB = uu.Load.lzma(vbSpec)
        binNum = VB['binNum']
        binCounts = VB['binCounts']
        del VB
    else:
        raise RuntimeError(f"No binned spectra.\n{'': <4s}{vbSpec}")

    xpix, ypix, sele, pixs = uu.Load.lzma(pfs)
    # saur,goods = uu.Load.lzma(sfs)
    # del saur
    xbix, ybix = GEO.rotate2D(xpix, ypix, PA)
    pfn = dDir.parent/'muse'/'obsData'/f"{galaxy}-poly-rot.xz"
    polyProps = dict(ec=POT.brown, linestyle='--', fill=False, zorder=100,
        lw=0.75, salpha=0.5)
    if pfn.is_file():
        aShape = uu.Load.lzma(pfn)
        aShape, pPatch = POT.polyPatch(POLYGON=aShape, Xpo=xbix, Ypo=ybix,
            **polyProps)
    else:
        aShape, pPatch = POT.polyPatch(Xpo=xbix, Ypo=ybix, **polyProps)
        uu.Write.lzma(pfn, aShape)
    xmin, xmax = np.amin(xbix), np.amax(xbix)
    ymin, ymax = np.amin(ybix), np.amax(ybix)
    xLen, yLen = np.ptp(xbix), np.ptp(ybix) # unmasked pixels

    saur, goods = uu.Load.lzma(pDir/galaxy/f"selection_SN{SN:02d}_{tEnd}.xz")
    xpix = np.compress(goods, xpix)
    ypix = np.compress(goods, ypix)
    xbix = np.compress(goods, xbix)
    ybix = np.compress(goods, ybix)

    cont = kwargs.get('cont', False)

    with logger.capture_all_output():
        decDir, cDirs, cKeys, nComp, teLL, lnGrid, histBinSize, dataVelScale,\
            RZ, spLL, laGrid, lmin, lmax, umetals, uages, ualphas, pixOff = \
            tf._oneTimeSpec(galaxy=galaxy, mPath=mPath, decDir=decDir,
            nCuts=nCuts, proj=proj, SN=SN, full=full, slope=slope, IMF=IMF,
            iso=iso, weighting=weighting, lOrder=lOrder, rescale=rescale,
            lsf=lsf, specRange=specRange, band=band, method=method,
            varIMF=varIMF, source=source, **kwargs)
    nLSpec, nSpat = laGrid.shape
    nTSpec, nMetals, nAges, nAlphas = lnGrid.shape
    nSSP = int(np.prod((nMetals, nAges, nAlphas), dtype=int))
    pred = f"0{len(repr(nComp)):d}"
    nComp = int(nComp)

    oDict = uu.Load.lzma(direc/f"decomp_{nCuts:d}.plt")
    if 'binFN' not in oDict.keys():
        oDict['binFN'] = 'bins_0.dat'
        oDict['apFN'] = 'aperture_0.dat'
        uu.Write.lzma(direc/f"decomp_{nCuts:d}.plt", oDict)
    binFN = oDict['binFN']
    apFN = oDict['apFN']
    dnPix, dgrid = uu.Read.bins(bDir/'infil'/binFN)
    dnbins = int(np.max(dgrid))
    dgrid -= 1
    dss = np.where(dgrid >= 0)[0]
    dx0, dx1, dnx, dy0, dy1, dny, dtheta = uu.Read.aperture(
        bDir/'infil'/apFN)
    ddx = np.abs((dx1-dx0)/dnx)
    ddy = np.abs((dy1-dy0)/dny)
    dpixs = np.min([ddx, ddy])
    dxr = np.arange(dnx)*dpixs + dx0 + 0.5*dpixs
    dyr = np.arange(dny)*dpixs + dy0 + 0.5*dpixs
    dxtss = uu._hash(dxr, np.full_like(dyr, 1)).ravel()[dss]
    dytss = uu._hash(np.full_like(dxr, 1), dyr).ravel()[dss]
    dtestX, dtestY = GEO.rotate2D(dxtss, dytss, dtheta)
    duPix, dpInverse, dpCounts = np.unique(dgrid[dss], return_inverse=True,
        return_counts=True)
    dpCount = dpCounts[dpInverse]

    biI = INF['bins'][0]
    bCount = biI['pCountsBin']
    # grid = np.array(biI['grid'], dtype=int).ravel()-1
    grid = np.array(biI['grid'], dtype=int).T.ravel()-1
    nbins = np.max(grid).astype(int)+1
    ss = np.where(grid >= 0)[0]

    if np.max(dpCount) > 1: # at least one bin contains more than one pixel
        # a quick way to check if the oberved scheme was used
        dgrid = grid
        dss = ss
        dnbins = nbins
        dpCount = bCount

    nzComp = np.array(oDict['nzComp'], dtype=int)
    nnOrb = plp.Path(*oDict['nnOrb'])
    oClass = plp.Path(*oDict['oClass'])
    obClass = plp.Path(*oDict['obClass'])
    bLKey = uu.keySep.join([nnOrb.parent.parent.name, nnOrb.parent.name])
    bLKey = uu.rReplace(bLKey, uu.keySep, os.sep, 1)
    nnOrb = plp.Path(bDir, decDir, nnOrb.parent.name, nnOrb.name)
    oClass = plp.Path(bDir, decDir, oClass.parent.name, oClass.name)
    obClass = plp.Path(bDir, decDir, obClass.parent.name, obClass.name)
    fpd = uu._deetExtr(bLKey)
    apDir = bDir/bLKey/'nn_aphist.out'
    maDir = (bDir/bLKey).parent/'datfil'/'mass_aper.dat'

    NOrbs, inds, energs, I2s, I3s, regs, types, weights, lcuts =\
        uu.Read.orbits(nnOrb)
    cWeights = np.zeros(nComp)
    for jk, comp in enumerate(nzComp):
        cWeights[jk] = np.ma.sum(weights[oDict['wheres'][f"{comp:{pred}d}"]])

    kiBin = INF['kin']['nbins'][0]
    assert nbins == kiBin, 'Output does not agree with input bins\nInput:'+\
        f"{kiBin}\nOutput: {nbins}"

    wbin, hN, histBinSize, hArr = uu.Read.apertureHist(apDir)
    logger.log(f"{'Mass outside of the histograms:': <45s}"\
          f"{np.sum(hArr[:, 0] + hArr[:, wbin * 2]):5.5}")

    fullBin, fullID, fullK0 = uu.Read.massAperture(maDir)
    logger.log(f"{'Mass normalisation is:': <45s}"\
        f"{np.sum(hArr) / np.sum(fullK0):5.5}")
    if isinstance(proj, list):
        pStr = ''.join([str(f) for f in proj])
    else:
        pStr = str(proj)
    plt.close('all')
    massNorm = fullK0

    apMassFile = direc/f"apMass_i{proj}_{nComp:{pred}d}.xz"
    if apMassFile.is_file():
        aperMass = uu.Load.lzma(apMassFile)
    else:
        aperMass = np.ma.ones((nSpat, nComp), dtype=float)*np.nan
        ERR = []
        for cn, cDir in tqdm(enumerate(cDirs), desc='Mass', total=nComp):
            try:
                maFile = cDir/'declib_apermass.out'
                nbin, ID, k0 = uu.Read.massAperture(maFile)
                aperMass[:, cn] = k0
            except:
                ERR += [cDir.name]
        if len(ERR) > 0:
            logger.log(ERR)
            breakpoint()
        uu.Write.lzma(apMassFile, aperMass)
    aperMass = np.ma.masked_invalid(aperMass)
    norma = np.sum(aperMass, axis=1)

    logger.log('Done.', flush=True)
    apFile = cDirs[0]/'declib_aphist.out'
    wbin, hN, histBinSize, hArr = uu.Read.apertureHist(apFile)
    # Load the parameters regardless
    apHistFile = direc/f"apHists_i{pStr}_{nComp:{pred}d}.jl"
    if apHistFile.is_file():
        logger.log('Reading histograms...', flush=True)
        apHists = uu.Load.jobl(apHistFile)
    else:
        apFile = cDirs[0]/'declib_aphist.out'
        wbin, hN, histBinSize, cArr = uu.Read.apertureHist(apFile)
        logger.log('Generating histograms...', flush=True)
        apHists = np.ma.ones((*cArr.shape, nComp))*np.nan
        ERR = []
        for cn, cDir in tqdm(enumerate(cDirs), desc='Components',
            total=nComp):
            try:
                apFile = cDir/'declib_aphist.out'
                wbin, hN, histBinSize, cArr = uu.Read.apertureHist(
                    apFile)
                apHists[:, :, cn] = cArr
            except:
                ERR += [cDir.stem]
        if len(ERR) > 0:
            logger.log(ERR)
            pdb.set_trace()
        uu.Write.jobw(apHistFile, apHists)
    logger.log('Done.')
    apHists = np.ma.masked_invalid(apHists)
    nApHists = (apHists*(massNorm/norma)[:, np.newaxis, np.newaxis])

    zarrDir = curdir/f"{galaxy}_{lOrder:02d}"
    nVel = hArr.shape[-1]
    nProcs = kwargs.get('nProcs', 1)
    
    with logger.capture_all_output():
        runner = PipelineRunner(zarrDir, nSpat, nComp, nVel, nSSP, nLSpec,
            nTSpec, tem_pix=copy(teLL), obs_pix=copy(spLL), lOrder=lOrder)
    plot_dir  = runner.mgr.root_dir/'plots'
    plot_dir.mkdir(exist_ok=True)
    
    z = runner.z

    logger.log(f"Zarr store type: {type(runner.z.store)}")
    logger.log(f"Zarr path: {getattr(runner.z.store, 'path', 'no path attribute')}")

    # Ensure HyperCube exists (create if missing)
    models_key = "HyperCube/models"
    if models_key not in z:
        logger.log("[CubeFit] HyperCube missing—creating now...")
        with logger.capture_all_output():
            runner.mgr.create_hypercube(
                batch_size=kwargs.pop('batch_size', 64),
                templates_fft=runner.templates_fft,
                rebin_matrix=runner.rebin_matrix,
                tem_pix=copy(teLL),
                obs_pix=copy(spLL),
                max_workers=nProcs,
            )
        logger.log("[CubeFit] HyperCube created.")

    # Reconstruct model cube (or load if already populated)
    if is_cube_populated(z, "ModelCube", nSpat, nLSpec):
        logger.log("[CubeFit] ModelCube exists in Zarr—loading.")
        CUBE = z["ModelCube"][:]
    else:
        logger.log("[CubeFit] ModelCube not found—recomputing in parallel (batched).")
        with logger.capture_all_output():
            CUBE = parallel_model_cube_global_batched(
                z=z,
                x_global=z["X_global"][:],
                nSpat=nSpat,
                nLSpec=nLSpec,
                n_workers=nProcs,
                array_name="ModelCube",
            )[:]  # load to RAM only if you need it immediately
        logger.log("[CubeFit] ModelCube recomputed and saved.")

    logger.log("CUBE shape:", CUBE.shape)

    residuals = z["DataCube"][:] - CUBE
    res_norm = np.linalg.norm(residuals, axis=1)
    if "Variance" in z:
        variance = z["Variance"][:]
        chi2 = np.sum((residuals**2) / variance, axis=1)
        rchi2 = chi2 / nLSpec
    else:
        rchi2 = res_norm / np.sqrt(nLSpec)

    plt.figure(figsize=(6, 4))
    plt.hist(rchi2, bins=40, alpha=0.7)
    plt.xlabel(r"Reduced $\chi^2$" if "Variance" in z else
        r"${\rm Norm}/\sqrt{N_{\rm pix}}$")
    plt.ylabel("Number of apertures")
    plt.title("Distribution of fit quality")
    plt.tight_layout()
    plt.savefig(os.path.join(plot_dir, "chi2_hist.png"))
    plt.close()

    if 'spec' in pplots:
        logger.log("Generating spectrum plots...")
        with logger.capture_all_output():
            parallel_spectrum_plots(
                z,
                CUBE,
                np.exp(spLL),
                rchi2,
                n=10,
                plot_dir=plot_dir,
                n_workers=nProcs,
                tag=f"C{nComp:04d}",
                mask=z["Mask"][:] if "Mask" in z else None,
            )

    if 'mw' in pplots:
        laGrid = np.ma.masked_less_equal(laGrid, 0.0)
        CUBE = np.ma.masked_less_equal(CUBE, 0.0)
        flux = np.ma.masked_invalid(
            # (np.ma.sum(laGrid, axis=0)/binCounts)[binNum], 0.))
            (np.ma.sum(laGrid, axis=0)/binCounts))
        modSB = np.ma.masked_array( # re-scale to original data levels
            (np.ma.sum(CUBE, axis=1)/binCounts),
            # (np.ma.sum(CUBE, axis=0)*laScales/binCounts)[binNum],
            mask=np.ma.getmaskarray(flux))
        fmin, fmax = np.log10(np.ma.min(flux)), np.log10(np.ma.max(flux))
        pren = 2
        miText = POT.prec(pren, fmin)
        maText = POT.prec(pren, fmax)
        gs = gridspec.GridSpec(3, 1, hspace=0., wspace=0.)
        fig = plt.figure(figsize=plt.figaspect((yLen*3.)/xLen)*0.75)
        ax = fig.add_subplot(gs[0])
        cnt = dbi(xpix, ypix, np.log10(flux[binNum]), pixelsize=pixs, angle=PA,
            cmap='gist_heat', vmin=fmin, vmax=fmax)
        ax.set_xticklabels([])
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymin, ymax)
        # ax.add_patch(copy(pPatch))
        cax = POT.attachAxis(ax, 'top', 0.1)
        cb = plt.colorbar(cnt, cax=cax, orientation='horizontal')
        lT = cax.text(0.5, 0.5, fr"$L\ [{UTS.lsun}]$", va='center', ha='center',
            color=POT.pgreen, transform=cax.transAxes)
        lT.set_path_effects([PathEffects.withStroke(linewidth=1.5,
            foreground='k')])
        cax.text(1e-3, 0.5, miText, va='center', ha='left', color='white',
            transform=cax.transAxes)
        cax.text(1.0-1e-3, 0.5, maText, va='center', ha='right', color='black',
            transform=cax.transAxes)
        cb.set_ticks([])
        ax = fig.add_subplot(gs[1])
        dbi(xpix, ypix, np.log10(modSB[binNum]), pixelsize=pixs, angle=PA,
            cmap='cet_fire', vmin=fmin, vmax=fmax)
        ax.set_xticklabels([])
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymin, ymax)
        # ax.add_patch(copy(pPatch))

        delta = (flux-modSB)/flux
        ax = fig.add_subplot(gs[2])
        cnt = dbi(xpix, ypix, delta[binNum], pixelsize=pixs, angle=PA,
            cmap=divcmap, vmin=-0.1, vmax=0.1)
        cax = POT.attachAxis(ax, 'top', 0.1, mid=True)
        cb = plt.colorbar(cnt, cax=cax, orientation='horizontal')
        lT = cax.text(0.5, 0.5, r'$(D-M)/D$', va='center', ha='center',
            color=POT.pgreen, transform=cax.transAxes)
        lT.set_path_effects([PathEffects.withStroke(linewidth=1.5,
            foreground='k')])
        cax.text(1e-3, 0.5, '-0.1', va='center', ha='left', color='white',
            transform=cax.transAxes)
        cax.text(1.0-1e-3, 0.5, '0.1', va='center', ha='right', color='white',
            transform=cax.transAxes)
        cb.set_ticks([])
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymin, ymax)
        # ax.add_patch(copy(pPatch))

        BIG = fig.add_subplot(gs[:])
        BIG.set_frame_on(False)
        BIG.set_xticks([])
        BIG.set_yticks([])
        BIG.set_xlabel(r'$x\ [{\rm arcsec}]$', labelpad=25)
        BIG.set_ylabel(r'$y\ [{\rm arcsec}]$', labelpad=25)

        plt.savefig(spDir/\
            f"modelCube_{nComp:{pred}d}_i{proj}{tag}_{lOrder:02d}.png")

    # 7. Print summary
    print(f"Mean reduced χ²: {np.mean(rchi2):.2f} ± {np.std(rchi2):.2f}")
    worst = np.argmax(rchi2)
    best = np.argmin(rchi2)
    print(f"Worst fit: aperture {worst} (χ² = {rchi2[worst]:.2f})")
    print(f"Best fit:  aperture {best} (χ² = {rchi2[best]:.2f})")
    print(f"[CubeFit] All plots and maps saved in {plot_dir}")