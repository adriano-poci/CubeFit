# -*- coding: utf-8 -*-
r"""
    cube_bcd.py
    Adriano Poci
    University of Oxford
    2025

    Block Coordinate Descent (BCD) solvers for CubeFit global fitting.

    Parallelized, matrix-free, block-wise optimizers for extremely large
    IFU data cubes. Main block strategy: update all weights for one dynamical
    component (across all spatial apertures and populations) per step.

    Authors
    -------
    Adriano Poci <adriano.poci@physics.ox.ac.uk>

History
-------
1.0:    11 August 2025
"""

from __future__ import annotations

import numpy as np
from scipy.optimize import minimize, nnls
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm
from numpy.random import default_rng
import time

from CubeFit.cube_utils import comp_loss_for_total
from CubeFit.model_cube import ModelCube
from CubeFit.logger import get_logger

logger = get_logger()

# ------------------------------------------------------------------------------

def optimize_component_spatial_block(
    c, spat_indices, x0_block, x_fixed, y_cube, losvd_cube, templates_fft,
    rebin_matrix, tem_pix, obs_pix, nLSpec, nComp, nPop, nnls_solver
):
    """
    Optimize all weights for component c and a spatial block (all pops),
    holding all others fixed.
    """
    nSpat_block = len(spat_indices)
    def comp_spat_loss(x_block_flat):
        x_tmp = x_fixed.copy()
        for i, s in enumerate(spat_indices):
            x_tmp[c, s, :] = x_block_flat[i * nPop:(i + 1) * nPop]
        y_model_block = []
        for i, s in enumerate(spat_indices):
            losvd = losvd_cube[s]
            A = ModelCube(
                templates_fft,
                rebin_matrix,
                losvd,
                tem_pix,
                obs_pix,
            ).convolve()
            weights = x_tmp[:, s, :]
            y_mod = np.sum(A * weights[None, :, :], axis=(1,2))
            y_model_block.append(y_mod)
        y_model_block = np.vstack(y_model_block)
        y_true_block = y_cube[spat_indices]
        return 0.5 * np.sum((y_true_block - y_model_block) ** 2)

    bounds = [(0, None)] * (nSpat_block * nPop)
    res = minimize(
        fun=comp_spat_loss,
        x0=x0_block,
        method='L-BFGS-B' if nnls_solver == 'lbfgsb' else 'SLSQP',
        bounds=bounds,
        options={'maxiter': 100, 'disp': False}
    )
    return (c, spat_indices, res.x)

# ------------------------------------------------------------------------------

def bcd_global_by_component_and_spatial_block_parallel(
    y_cube, losvd_cube, templates_fft, rebin_matrix,
    tem_pix, obs_pix, nLSpec, nComp, nPop,
    spatial_block_size=32,
    max_iter=5,
    nnls_solver='lbfgsb',
    n_workers=8,
    x_init=None,
    verbose=True,
):
    """
    Hierarchical parallel BCD: block by component and spatial region.

    Each worker fits one (component, spatial block) at a time.

    Parameters
    ----------
    y_cube : ndarray
        Observed data, shape (nSpat, nLSpec).
    losvd_cube : ndarray
        LOSVDs, shape (nSpat, nVel, nComp).
    templates_fft, rebin_matrix : arrays for ModelCube.
    tem_pix, obs_pix : arrays for ModelCube.
    nLSpec, nComp, nPop : int
    spatial_block_size : int
        Number of spatial apertures per block.
    max_iter : int
        Number of BCD cycles.
    nnls_solver : str
        'lbfgsb' (default) or 'SLSQP'.
    n_workers : int
        Number of parallel processes.
    x_init : ndarray or None
        Initial guess, shape (nComp, nSpat, nPop). If None, uses small positive.
    verbose : bool

    Returns
    -------
    x : ndarray
        Global solution, shape (nComp, nSpat, nPop).
    """

    nSpat = y_cube.shape[0]
    if x_init is None:
        x = np.full((nComp, nSpat, nPop), 1e-4)
    else:
        x = x_init.copy()

    for it in tqdm(range(max_iter), desc="BCD Iterations", ncols=80):
        for c in tqdm(range(nComp), desc="Components", leave=False, ncols=80):
            spat_blocks = [np.arange(b, min(b + spatial_block_size, nSpat))
                for b in range(0, nSpat, spatial_block_size)]
            block_jobs = []
            x_fixed = x.copy()
            with tqdm(total=len(spat_blocks), desc=f"Comp {c+1}/{nComp}", leave=False, ncols=80) as pbar:
                with ProcessPoolExecutor(max_workers=n_workers) as pool:
                    futures = []
                    for spat_indices in spat_blocks:
                        x0_block = x[c, spat_indices, :].ravel()
                        job = (c, spat_indices, x0_block, x_fixed,
                            y_cube, losvd_cube, templates_fft, rebin_matrix,
                            tem_pix, obs_pix, nLSpec, nComp, nPop, nnls_solver)
                        futures.append(pool.submit(
                            optimize_component_spatial_block, *job))
                    for fut in as_completed(futures):
                        c_out, spat_indices_out, x_block = fut.result()
                        x[c_out, spat_indices_out, :] = x_block.reshape(
                            len(spat_indices_out), nPop)
                        if verbose:
                            logger.log(f"[BCD] Comp {c+1}/{nComp}, "
                                f"spatial {spat_indices_out[0]}:{spat_indices_out[-1]} updated.",
                                flush=True)
                        pbar.update(1)
        if verbose:
            total_loss = comp_loss_for_total(
                x, y_cube, losvd_cube, templates_fft,
                rebin_matrix, tem_pix, obs_pix, nSpat, nLSpec, nComp, nPop)
            logger.log(
                f"[BCD] Iter {it+1} complete. Total loss: {total_loss:.4e}",
                flush=True)
    return x

# ------------------------------------------------------------------------------
