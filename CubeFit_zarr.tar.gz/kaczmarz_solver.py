# -*- coding: utf-8 -*-
r"""
    kaczmarz_solver.py
    Adriano Poci
    University of Oxford
    2025

    Platforms
    ---------
    Unix, Windows

    Synopsis
    --------
    Randomised Kaczmarz NNLS solvers for CubeFit: supports per-aperture, global
    (full-cube), block-constrained, and penalized fits. Designed for extremely
    large, memory-efficient IFU data decomposition.

    Authors
    -------
    Adriano Poci <adriano.poci@physics.ox.ac.uk>

History
-------
v1.0:   Basic per-aperture solver. 2025
v1.1:   Parallel global fit, block-sum constraints, soft penalties. 2025
v1.2:   Initialisation from stacked NNLS, custom momentum/projection logic. 2025
"""

from __future__ import annotations
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm
from scipy.optimize import nnls
import numpy as np
import matplotlib.pyplot as plt
from numba import njit, prange
from typing import Sequence, Tuple, Dict, List

from CubeFit.cube_utils import comp_loss_for_total
from CubeFit.model_cube import ModelCube
from CubeFit.logger import get_logger

logger = get_logger()

# ------------------------------------------------------------------------------

def aperture_worker(
    s_list, x_shared, z, tem_pix, obs_pix, nLSpec, templates_fft, rebin_matrix,
    pixels_per_aperture, lr, momentum, mask=None
):
    """
    Worker for batched global Kaczmarz NNLS (one process chunk).

    Parameters
    ----------
    s_list : list[int]
        Aperture indices to process in this worker.
    x_shared : ndarray
        Current global solution vector (shared snapshot).
    z : Zarr group
        Main Zarr storage object.
    tem_pix : ndarray
        Template wavelength grid.
    obs_pix : ndarray
        Observed wavelength grid.
    nLSpec : int
        Number of observed spectral pixels.
    pixels_per_aperture : int
        Number of random pixels per aperture per batch.
    lr : float
        Kaczmarz step size (relaxation).
    momentum : float
        Kaczmarz momentum parameter [0, 1).
    mask : ndarray or None
        1D boolean array for spectral mask (length nLSpec).
        If given, only masked pixels will be used for updates.

    Returns
    -------
    dx_sum : ndarray
        Kaczmarz update to apply (same shape as x).
    """
    dx_sum = np.zeros_like(x_shared)
    v_sum = np.zeros_like(x_shared)
    rng = np.random.default_rng()
    for s in s_list:
        # Build model matrix for this aperture
        A_s = ModelCube(
            templates_fft,
            rebin_matrix,
            z["LOSVD"][s],
            tem_pix,
            obs_pix,
        ).convolve()
        # Valid pixel indices
        if mask is not None:
            valid_pixels = np.where(mask)[0]
            if valid_pixels.size == 0:
                continue  # No valid pixels; skip
        else:
            valid_pixels = np.arange(nLSpec)
        # Pick pixels_per_aperture random pixels for Kaczmarz steps
        for _ in range(pixels_per_aperture):
            if valid_pixels.size == 0:
                break  # Defensive: skip if no valid pixels at all
            p = rng.choice(valid_pixels)
            A_row = A_s[p, :]
            y_val = z["DataCube"][s, p]
            A_row_norm2 = np.dot(A_row, A_row)
            if A_row_norm2 == 0.0:
                continue
            r = y_val - np.dot(A_row, x_shared)
            dx = lr * (r / A_row_norm2) * A_row
            v_sum = momentum * v_sum + dx
            dx_sum += v_sum
    return dx_sum

# ------------------------------------------------------------------------------

def batched_fft_convolve(
    templates_fft, losvd_batch, nTSpec, nVel, fft_size
):
    """
    Batched convolution using FFT, in pure NumPy.

    Parameters
    ----------
    templates_fft : ndarray
        FFT of templates, shape (nPop, fft_size).
    losvd_batch : ndarray
        LOSVDs for batch, shape (nBatch, nVel, nComp).
    nTSpec : int
        Number of template spectral pixels (pre-FFT).
    nVel : int
        Number of velocity bins in LOSVD kernels.
    fft_size : int
        FFT size.

    Returns
    -------
    convolved : ndarray
        Convolved templates for batch, shape (nBatch, nPop, nComp, nTSpec).
    """
    nBatch, nVel_, nComp = losvd_batch.shape
    nPop, _ = templates_fft.shape
    convolved = np.zeros((nBatch, nPop, nComp, nTSpec), dtype=np.float64)
    for i in range(nBatch):
        losvd_fft = np.fft.fft(losvd_batch[i].T, n=fft_size, axis=1)
        product_fft = templates_fft[:, np.newaxis, :] * losvd_fft[np.newaxis, :, :]
        convolved_full = np.fft.ifft(product_fft, axis=2).real
        start_idx = (nVel - 1) // 2
        end_idx = start_idx + nTSpec
        convolved[i] = convolved_full[:, :, start_idx:end_idx]
    return convolved

# ------------------------------------------------------------------------------

@njit(parallel=True, fastmath=True)
def batch_rebin(
    convolved, rebin_matrix
):
    """
    Numba-accelerated rebinning for a batch of convolved spectra.

    Parameters
    ----------
    convolved : ndarray
        (nBatch, nPop, nComp, nTSpec)
    rebin_matrix : ndarray
        (nLSpec, nTSpec)

    Returns
    -------
    rebinned : ndarray
        (nBatch, nLSpec, nComp, nPop)
    """
    nBatch, nPop, nComp, nTSpec = convolved.shape
    nLSpec = rebin_matrix.shape[0]
    rebinned = np.zeros((nBatch, nLSpec, nComp, nPop), dtype=np.float64)
    for i in prange(nBatch):
        for c in prange(nComp):
            for p in prange(nPop):
                rebinned[i, :, c, p] = rebin_matrix @ convolved[i, p, c, :]
    return rebinned

# ------------------------------------------------------------------------------

def batch_aperture_worker(
    s_list, x_shared, z, templates_fft, rebin_matrix, tem_pix, obs_pix, nLSpec,
    nTSpec, nVel, pixels_per_aperture, lr, momentum, mask=None
):
    """
    Worker function for a batch of spatial apertures in global Kaczmarz NNLS.

    Parameters
    ----------
    s_list : list[int]
        List of aperture indices to process in this worker.
    x_shared : np.ndarray
        Current global solution vector (a snapshot, not shared memory).
    z : Zarr group
        Main Zarr storage object with 'DataCube', 'LOSVD', etc.
    templates_fft : np.ndarray
        FFT of all templates, shape (nPop, fft_size).
    rebin_matrix : np.ndarray
        Precomputed rebinning matrix, shape (nLSpec, nTSpec).
    tem_pix : np.ndarray
        Template wavelength grid.
    obs_pix : np.ndarray
        Observed wavelength grid.
    nLSpec : int
        Number of observed spectral pixels.
    nTSpec : int
        Number of template spectral pixels.
    nVel : int
        Number of velocity bins in LOSVD.
    pixels_per_aperture : int
        Number of random spectral pixels per aperture for Kaczmarz updates.
    lr : float
        Kaczmarz step size (relaxation).
    momentum : float
        Kaczmarz momentum parameter [0, 1).
    mask : np.ndarray or None, optional
        Boolean spectral mask, length nLSpec. If given, only masked
        pixels are updated.

    Returns
    -------
    dx_sum : np.ndarray
        Accumulated update to the global solution vector (same shape as x_shared).

    Notes
    -----
    - Performs batched FFT convolution using `numba_convolve_batch` for
      all apertures in the batch.
    - Rebins convolved templates onto the observed wavelength grid.
    - For each aperture, performs `pixels_per_aperture` Kaczmarz updates
      using randomly sampled good pixels (per mask if provided).
    - Returns the sum of Kaczmarz updates to be added to the global x
      in the main solver loop.
    """
    nBatch = len(s_list)
    dx_sum = np.zeros_like(x_shared)
    v_sum = np.zeros_like(x_shared)
    rng = np.random.default_rng()
    fft_size = templates_fft.shape[1]
    losvd_batch = np.stack([z["LOSVD"][s] for s in s_list], axis=0)  # (nBatch, nVel, nComp)
    # 1. Batched FFT convolution (NumPy)
    convolved = batched_fft_convolve(
        templates_fft, losvd_batch, nTSpec, nVel, fft_size
    )  # (nBatch, nPop, nComp, nTSpec)
    # 2. Numba-accelerated rebin
    rebinned = batch_rebin(convolved, rebin_matrix)  # (nBatch, nLSpec, nComp, nPop)
    # 3. Main Kaczmarz loop (unchanged)
    for idx_in_batch, s in enumerate(s_list):
        A_s = rebinned[idx_in_batch].reshape(nLSpec, -1)  # (nLSpec, nComp*nPop)
        if mask is not None:
            valid_pixels = np.where(mask)[0]
            if valid_pixels.size == 0:
                continue
        else:
            valid_pixels = np.arange(nLSpec)
        for _ in range(pixels_per_aperture):
            if valid_pixels.size == 0:
                break
            p = rng.choice(valid_pixels)
            A_row = A_s[p, :]
            y_val = z["DataCube"][s, p]
            A_row_norm2 = np.dot(A_row, A_row)
            if A_row_norm2 == 0.0:
                continue
            r = y_val - np.dot(A_row, x_shared)
            dx = lr * (r / A_row_norm2) * A_row
            v_sum = momentum * v_sum + dx
            dx_sum += v_sum
    return dx_sum

# ------------------------------------------------------------------------------

def project_blocks_to_relative_weights(
    x, nComp, nPop, rel_weights, verbose=False
):
    """
    Project x so that each block sum matches rel_weights * total sum,
    only if all blocks and S_tot are comfortably above zero.
    Prints diagnostics if enabled.

    Parameters
    ----------
    x : ndarray
        Solution vector (length nComp*nPop).
    nComp : int
        Number of dynamical components (blocks).
    nPop : int
        Number of template populations per component.
    rel_weights : ndarray, shape (nComp,)
        Target relative block sums (should sum to 1).
    verbose : bool, default=False
        Print warnings and diagnostics.

    Returns
    -------
    x : ndarray
        Projected solution vector.
    """
    block_sums = np.array([
        x[c * nPop : (c + 1) * nPop].sum() for c in range(nComp)
    ])
    S_tot = block_sums.sum()
    if verbose:
        logger.log(f"[Kaczmarz] Block sums: {block_sums}, S_tot: {S_tot:.3e}")
    if S_tot < 1e-12 or np.any(block_sums < 1e-12):
        if verbose:
            logger.log("[Kaczmarz] Projection skipped: S_tot or a block is zero.")
        return x
    target_block_sums = rel_weights * S_tot
    for c in range(nComp):
        block = x[c * nPop : (c + 1) * nPop]
        actual_sum = block.sum()
        if actual_sum > 1e-12:
            block *= target_block_sums[c] / actual_sum
            x[c * nPop : (c + 1) * nPop] = block
    return x

# ------------------------------------------------------------------------------

def apply_block_penalty(x, nComp, nPop, rel_weights, lam=1e-2):
    """
    Apply a soft penalty to the difference between block sums and rel_weights.

    Parameters
    ----------
    x : ndarray
        Solution vector (length nComp*nPop).
    nComp : int
        Number of dynamical components (blocks).
    nPop : int
        Number of template populations per component.
    rel_weights : ndarray, shape (nComp,)
        Target relative block sums (should sum to 1).
    lam : float, default=1e-2
        Soft penalty strength.

    Returns
    -------
    x : ndarray
        Penalized solution vector.
    """
    block_sums = np.array([
        x[c * nPop : (c + 1) * nPop].sum() for c in range(nComp)
    ])
    S_tot = block_sums.sum()
    if S_tot > 0:
        current_ratios = block_sums / S_tot
        penalty_grad = np.zeros_like(x)
        for c in range(nComp):
            diff = current_ratios[c] - rel_weights[c]
            penalty_grad[c * nPop : (c + 1) * nPop] = diff / nPop
        x = x - lam * S_tot * penalty_grad
        x[x < 0] = 0.0
    return x

# ------------------------------------------------------------------------------

def _batch_global_grad_worker(
    zarr_store,
    batch_idx: int,
    abs_ids: Sequence[int],          # absolute aperture ids
    within_idx: np.ndarray,          # within-batch 0..B-1 (same order as abs_ids)
    pixel_idx: np.ndarray,           # (m,) pixel indices (masked)
    x_blocks: np.ndarray,            # (nComp, nPop), current global x
) -> Tuple[np.ndarray, float]:
    zroot = zarr.group(store=str(zarr_store), zarr_format=3)
    models = zroot["HyperCube/models"]     # (n_batches, B, nComp, nPop, nLSpec)
    ycube  = zroot["DataCube"]             # (nSpat, nLSpec)

    within_idx = np.asarray(within_idx, dtype=np.int64)
    abs_ids    = np.asarray(abs_ids,    dtype=np.int64)
    pixel_idx  = np.asarray(pixel_idx,  dtype=np.int64)

    # (m, nComp, nPop, nLSpec)
    mb = models.get_orthogonal_selection(
        (np.asarray([batch_idx], np.int64),
         within_idx, slice(None), slice(None), slice(None))
    )[0]
    mb = np.asarray(mb, dtype=np.float64, order="C")

    # Observed spectra for these apertures
    y = ycube.get_orthogonal_selection((abs_ids, pixel_idx))  # (m, |P|)
    y = np.asarray(y, dtype=np.float64, order="C")

    n_ap = mb.shape[0]
    nComp = mb.shape[1]
    nPop  = mb.shape[2]
    nP    = pixel_idx.size

    # Predict yhat for sampled pixels using current global x
    # x_blocks: (nComp, nPop)
    # For each sample (i,p): yhat = sum_c dot(mb[i,c,:,p], x_blocks[c,:])
    # Compute in batch:
    # M_ipc = mb[i, c, :, p] -> shape (n_ap, nComp, nP, nPop)
    M = mb[:, :, :, pixel_idx].transpose(0, 1, 3, 2)  # (n_ap, nComp, nP, nPop)
    xB = x_blocks[None, :, None, :]                   # (1, nComp, 1, nPop)
    yhat = np.sum(M * xB, axis=(1, 3))               # (n_ap, nP)
    r = y - yhat                                      # (n_ap, nP)

    # g = A^T r per block: g[c,:] += sum_{i,p} r[i,p] * mb[i,c,:,p]
    # Use einsum: r[i,p] * mb[i,c,k,p] -> g[c,k]
    g_blocks = np.einsum('ip,ickp->ck', r, mb[:, :, :, pixel_idx], optimize=True)

    # denom = ||A_S||_F^2 = sum_{i,p,c} ||mb[i,c,:,p]||^2
    denom = float(np.einsum('ickp,ickp->', mb[:, :, :, pixel_idx],
                            mb[:, :, :, pixel_idx], optimize=True))

    return g_blocks, denom

# ------------------------------------------------------------------------------

class KaczmarzSolver:
    """
    Randomized Kaczmarz NNLS.

    Parameters
    ----------
    max_iter     : int   maximum sweeps
    tol          : float stop when ||r|| <= tol
    lr           : float relaxation / step size
    momentum     : float momentum term [0, 1)
    """

    def __init__(
        self,
        max_iter: int = 8000,
        tol: float = 1e-4,
        lr: float = 0.25,
        momentum: float = 0.6,
    ) -> None:
        self.max_iter = max_iter
        self.tol = tol
        self.lr = lr
        self.momentum = momentum

    # --------------------------------------------------------------------------
    
    def solve(
        self, A: np.ndarray, y: np.ndarray, verbose: bool = False
    ) -> tuple[np.ndarray, list[float]]:
        """
        Randomised Kaczmarz NNLS.

        Returns
        -------
        x          : ndarray, (n_cols,)
        residuals  : list[float]  residual‑norm after each checkpoint
        """
        m, n = A.shape
        x = np.zeros(n)
        r = y.copy()                     # residual  r = y - A x
        v = np.zeros_like(x)             # momentum buffer
        residuals: list[float] = []

        row_norm2 = (A * A).sum(axis=1)
        p = row_norm2 / row_norm2.sum()  # sampling probabilities

        for k in range(1, self.max_iter + 1):
            i = np.random.choice(m, p=p)
            ai = A[i]
            ai_norm2 = row_norm2[i]
            if ai_norm2 == 0.0:          # skip zero row
                continue

            alpha = r[i] / ai_norm2
            v = self.momentum * v + self.lr * alpha * ai
            x += v
            x[x < 0] = 0.0               # NNLS projection
            r = y - A @ x                # update residual

            if k % 500 == 0:
                res = np.linalg.norm(r)
                residuals.append(res)
                if verbose:
                    logger.log(f"[{k}] residual {res:.3e}")

                # adaptive early‑stop: tiny improvement → break
                if len(residuals) > 1:
                    if residuals[-2] - res < 1e-4:
                        if verbose:
                            logger.log("Δres < 1e‑4, stopping early.")
                        break

                # absolute tolerance
                if res <= self.tol:
                    if verbose:
                        logger.log("Residual below tol, stopping.")
                    break

        return x, residuals
    # ----------------------------------------------------------------------
    # New: block Kaczmarz update on a contiguous slice of the global vector
    # ----------------------------------------------------------------------
    def solve_block(
        self,
        A_block: np.ndarray,     # (rows, L) or (rows, B)
        y: np.ndarray,           # (L,) or (B,)
        x_block: np.ndarray,     # (rows,)  -- THIS IS x̃ (internal variable)
        *,
        pixels: np.ndarray | None = None,
        comp_weights: np.ndarray | None = None,   # (nComp,) OR (rows,) prior (see docstring)
        nPop: int | None = None,                  # needed to expand to rows if comp_weights is (nComp,)
        row_order: str = "c-major",               # row = c*nPop + p (default); currently only used for validation
        project_nonneg: bool = True,
        lr: float | None = None,
    ) -> tuple[np.ndarray, float]:
        """
        Perform a **block Kaczmarz** update on a (C,P)-tile with a **true prior** on components.
        The prior is incorporated **during** the update (column-scaling), not post-hoc.

        This method updates the **internal** variable :math:`\\tilde{x}` corresponding to an
        implicitly **column-scaled design**. The **physical** solution is
        :math:`x = w \\odot \\tilde{x}`, where `w` are per-row weights derived from
        the per-component prior.

        Parameters
        ----------
        A_block : ndarray, shape (rows, L) or (rows, B)
            Transposed design for the selected (C,P)-tile, flattened to `rows = C_tile * P_tile`.
            Each **row** corresponds to one (component, population) basis vector over the last
            spectral axis. Use (rows, L) for the full spectrum, or (rows, B) for a pixel subset.
        y : ndarray, shape (L,) or (B,)
            Observed spectrum (or the same pixel subset used by `A_block`).
        x_block : ndarray, shape (rows,)
            Current estimate of the **internal** variable :math:`\\tilde{x}` for this tile
            (the slice of the global vector that corresponds to the tile rows).
        pixels : ndarray[int] or None, optional
            If `A_block` is (rows, L) but you wish to use only a subset of pixels, pass their
            indices here. If `A_block` is already (rows, B), leave as `None`.
        comp_weights : ndarray or None, optional
            Component prior weights. Two supported forms:
            - **(nComp,)**: per-component positive weights (e.g., priors). Requires `nPop`.
                They will be **expanded to per-row weights** (repeated across populations).
            - **(rows,)**: pre-expanded per-row weights **for this tile**. In this case set
                `nPop=1` (or leave as is) and they will be used directly.
            All weights are clamped to a small positive epsilon to avoid division by zero.
        nPop : int or None, optional
            The number of populations. **Required** when `comp_weights` is `(nComp,)` so we can
            expand to per-row weights for the tile as `repeat(comp_weights, nPop)`.
            Ignored if `comp_weights` is already `(rows,)`.
        row_order : {"c-major", "p-major"}, default="c-major"
            Declares the row ordering convention for the global matrix. The update assumes
            `"c-major"` (`row = c*nPop + p`) which matches the reader default. If you use a
            different ordering, you should pre-expand `comp_weights` to `(rows,)` accordingly
            and pass it directly. (Parameter is currently informational here.)
        project_nonneg : bool, default=True
            Enforce **non-negativity** on the **physical** solution after the update:
            we project `z = w_rows * x̃_new` to `z >= 0` and map back via `x̃_new = z / w_rows`.
        lr : float or None, optional
            Learning rate (relaxation). If `None`, uses `self.lr`.

        Returns
        -------
        x_block_new : ndarray, shape (rows,)
            Updated **internal** variable :math:`\\tilde{x}` for this tile (write back to the
            corresponding slice of the global vector).
        rms_residual : float
            Root-mean-square of the residual on the selected pixel subset; useful for monitoring.

        Notes
        -----
        *True prior (column scaling)*:
        Incorporating `comp_weights` scales the **columns** of the physical design `A_phys`
        (equivalently, scales the **rows** of `A_block` which represents `A_phys^T`).
        We update the internal variable `x̃` using the **weighted** design:

        .. math::

            a_w = w \\odot a, \\quad
            r = y - a_w^T \\tilde{x}, \\quad
            \\tilde{x} \\leftarrow \\tilde{x} + \\alpha\\, \\frac{a_w\\, r}{\\|a_w\\|_2^2}

        The returned `x_block_new` is :math:`\\tilde{x}`; convert to physical `x = w \\odot \\tilde{x}`
        at the caller if you need the physical coefficients immediately.

        Examples
        --------
        >>> # A_tile_T: (rows, L), y: (L,), x_slice: (rows,)
        >>> x_slice, rms = solver.solve_block(A_tile_T, y, x_slice,
        ...                                   comp_weights=comp_w, nPop=nPop)
        """
        A = A_block if pixels is None else A_block[:, pixels]
        yv = y if pixels is None else y[pixels]

        # Expand per-component prior into per-row weights for this tile
        if comp_weights is not None:
            w_comp = np.asarray(comp_weights, dtype=np.float64)
            if w_comp.ndim != 1:
                raise ValueError("comp_weights must be 1-D: (nComp,) or (rows,).")
            if w_comp.size == A.shape[0]:
                # Already per-row for this tile
                w_rows = w_comp
            else:
                if nPop is None:
                    raise ValueError("solve_block: nPop is required when comp_weights is (nComp,).")
                # Repeat each component weight across populations
                w_rows = np.repeat(w_comp, nPop)
                if w_rows.size != A.shape[0]:
                    raise ValueError(
                        "solve_block: comp_weights expanded size does not match tile rows; "
                        "pass per-row weights of shape (rows,) or provide correct nPop."
                    )
            # Strictly positive to avoid division by zero
            eps = 1e-12
            w_rows = np.maximum(w_rows, eps)
            # Weighted design inside the step
            A_w = (w_rows[:, None] * A)  # (rows, B)
        else:
            w_rows = None
            A_w = A

        # Residual with weighted design: r = y - A_w^T x̃
        Ax = A_w.T @ x_block
        r = yv - Ax

        # Row norms and update
        row_norm2 = np.sum(A_w * A_w, axis=1, dtype=np.float64) + 1e-12
        lr_eff = self.lr if lr is None else lr
        dx = lr_eff * (A_w @ r) / row_norm2  # (rows,)
        x_new = x_block + dx

        # Nonnegativity on PHYSICAL x = w_rows ⊙ x̃, then map back
        if project_nonneg:
            if w_rows is None:
                np.maximum(x_new, 0.0, out=x_new)
            else:
                z = w_rows * x_new
                np.maximum(z, 0.0, out=z)
                x_new = z / w_rows

        rms = float(np.sqrt(np.mean(r * r)))
        return x_new, rms

    # --------------------------------------------------------------------------

    @staticmethod
    def solve_global_aperture_batched_parallel(
        z,
        tem_pix,
        obs_pix,
        nSpat,
        nLSpec,
        orbit_weights,
        nComp,
        templates_fft,          # unused here but kept for signature parity
        rebin_matrix,           # unused here (HyperCube already rebinned)
        apertures_per_batch=64,
        pixels_per_aperture=256,
        n_batches=5000,
        lr=0.25,
        momentum=0.0,           # not used in global block-Kaczmarz update
        tol=1e-4,
        n_workers=8,
        sample_residuals_every=10,
        lam=1e-6,
        enforce_weights=True,
        verbose=True,
        x_init=None,            # 1D (nComp*nPop,) or 2D (nComp,nPop)
        mask=None,              # (nLSpec,) boolean
        proj_delay=1000,
        **kwargs,
    ):
        """
        True-global Kaczmarz/row-block update: solve a single shared x of length
        nComp*nPop using HyperCube rows without materialising A.

        Each batch samples `apertures_per_batch` random apertures and
        `pixels_per_aperture` masked pixels per aperture, forms the row-block S,
        and applies:
            x <- x + lr * (A_S^T (y_S - A_S x)) / ||A_S||_F^2

        Data sources
        ------------
        - HyperCube/models: (n_batches_disk, B, nComp, nPop, nLSpec) float64
        - DataCube:         (nSpat, nLSpec) float64

        Parameters
        ----------
        orbit_weights : (nComp,)
            Target relative block sums for projection/penalty (sum to 1).
        enforce_weights : bool
            If True, after `proj_delay` batches project blocks to match
            `orbit_weights`. If False, apply soft penalty with `lam`.

        Returns
        -------
        x : (nComp*nPop,) float64
            Global non-negative solution vector.
        residuals : list[float]
            RMS residuals sampled every `sample_residuals_every` batches.
        """
        logger = get_logger()
        models = z["HyperCube/models"]
        n_batches_disk, B_disk, nComp_disk, nPop, nLSpec_disk = models.shape
        assert nComp == nComp_disk and nLSpec == nLSpec_disk

        # Masked pixel set
        if mask is not None:
            mask = np.asarray(mask, dtype=bool).reshape(-1)
            valid_pixels = np.where(mask)[0]
        else:
            valid_pixels = np.arange(nLSpec, dtype=np.int64)

        # Global x initialisation as (nComp, nPop)
        if x_init is None:
            x_blocks = np.full((nComp, nPop), 1e-4, dtype=np.float64)
            if verbose:
                logger.log("[Kaczmarz] Initialized global x to small positives.",
                        flush=True)
        else:
            v = np.asarray(x_init)
            if v.ndim == 1:
                need = nComp * nPop
                if v.size > need:
                    v = v[:need]
                elif v.size < need:
                    v = np.pad(v, (0, need - v.size))
                x_blocks = v.reshape(nComp, nPop).astype(np.float64, copy=False)
            elif v.ndim == 2 and v.shape == (nComp, nPop):
                x_blocks = v.astype(np.float64, copy=False)
            else:
                raise ValueError("x_init must be (nComp*nPop,) or (nComp,nPop).")
            if verbose:
                logger.log("[Kaczmarz] Using provided global x_init.", flush=True)

        residuals: List[float] = []

        # Helper to map absolute aperture ids to (batch_idx, within_idx)
        # assuming HyperCube batches are contiguous slices of size B_disk
        # except possibly the last.
        def to_batch_mapping(abs_ids: np.ndarray) -> Dict[int, np.ndarray]:
            groups: Dict[int, List[int]] = {}
            for a in abs_ids.tolist():
                bidx = a // B_disk
                if bidx >= n_batches_disk:
                    bidx = n_batches_disk - 1  # last partial batch
                groups.setdefault(bidx, []).append(a)
            # convert to np arrays and to within indices
            out: Dict[int, np.ndarray] = {}
            for bidx, lst in groups.items():
                arr = np.asarray(lst, dtype=np.int64)
                # batch_start = bidx * B_disk; within = abs - start
                # guard last batch possibly smaller:
                start = bidx * B_disk
                out[bidx] = arr - start
            return out

        rng = np.random.default_rng()

        # Pool outside the loop
        zarr_store = models.store  # pass the store to workers
        with ProcessPoolExecutor(max_workers=n_workers) as pool:
            pbar = tqdm(total=n_batches, desc="Global Kaczmarz (true)", ncols=80)
            for b in range(n_batches):
                # Sample apertures & pixels
                aps = rng.choice(nSpat, size=min(apertures_per_batch, nSpat),
                                replace=False)
                pix = rng.choice(valid_pixels,
                                size=min(pixels_per_aperture, valid_pixels.size),
                                replace=False)

                # Group apertures by HyperCube batch and build within indices
                groups = {}
                for a in aps:
                    bidx = a // B_disk
                    if bidx >= n_batches_disk:
                        bidx = n_batches_disk - 1
                    groups.setdefault(bidx, []).append(a)

                # Submit per-batch gradient jobs
                futures = []
                for bidx, abs_list in groups.items():
                    abs_ids = np.asarray(abs_list, dtype=np.int64)
                    start   = bidx * B_disk
                    within  = (abs_ids - start).astype(np.int64)
                    futures.append(pool.submit(
                        _batch_global_grad_worker,
                        zarr_store,
                        int(bidx),
                        abs_ids,
                        within,
                        pix,
                        x_blocks.copy(),  # small (nComp,nPop)
                    ))

                # Aggregate gradient and denom
                g = np.zeros_like(x_blocks)  # (nComp, nPop)
                denom = 0.0
                for fut in as_completed(futures):
                    g_i, d_i = fut.result()
                    g += g_i
                    denom += d_i

                # Kaczmarz update (block, normalized)
                if denom > 0:
                    x_blocks += (lr * g) / denom

                # Nonnegativity
                np.maximum(x_blocks, 0.0, out=x_blocks)

                # Projection / penalty (delayed)
                if b >= proj_delay:
                    if enforce_weights:
                        x_prev = x_blocks.copy()
                        x_vec  = x_blocks.ravel()
                        x_vec  = project_blocks_to_relative_weights(
                            x_vec, nComp, nPop, orbit_weights, verbose=False
                        )
                        x_blocks = x_vec.reshape(nComp, nPop)
                        if np.allclose(x_blocks, 0.0):
                            if verbose:
                                logger.log("[Kaczmarz] Projection zeroed x; "
                                        "keeping previous.", flush=True)
                            x_blocks = x_prev
                    else:
                        x_vec = x_blocks.ravel()
                        x_vec = apply_block_penalty(
                            x_vec, nComp, nPop, orbit_weights, lam=lam
                        )
                        x_blocks = x_vec.reshape(nComp, nPop)

                # Periodic residual diagnostic
                if ((b + 1) % sample_residuals_every) == 0:
                    # sample a small set fresh
                    aps_d = rng.choice(nSpat, size=min(16, nSpat), replace=False)
                    pix_d = rng.choice(valid_pixels,
                                    size=min(64, valid_pixels.size),
                                    replace=False)
                    # Group and evaluate residuals
                    num = 0.0
                    den = 0
                    for a in aps_d:
                        bidx = a // B_disk
                        if bidx >= n_batches_disk: bidx = n_batches_disk - 1
                        start = bidx * B_disk
                        within = int(a - start)
                        mb = models.get_orthogonal_selection(
                            (np.asarray([bidx], np.int64),
                            np.asarray([within], np.int64),
                            slice(None), slice(None), slice(None))
                        )[0, 0]  # (nComp, nPop, nLSpec)
                        mb = np.asarray(mb, dtype=np.float64, order="C")
                        y  = z["DataCube"].get_orthogonal_selection(
                            (np.asarray([a], np.int64), pix_d)
                        )[0]  # (|P|,)
                        yhat = np.einsum('ck,ckp->p', x_blocks, mb[:, :, pix_d],
                            optimize=True)  # (|P|,)
                        if mask is not None:
                            # pix_d already masked; nothing extra to do
                            pass
                        r = y - yhat
                        num += float(r @ r)
                        den += r.size
                    res = float(np.sqrt(num / max(den, 1)))
                    residuals.append(res)
                    if verbose:
                        logger.log(f"[{b+1}] RMS residual: {res:.5e}", flush=True)
                    if res < tol:
                        if verbose:
                            logger.log(f"Converged at batch {b+1} (RMS {res:.3e})",
                                    flush=True)
                        pbar.update(1)
                        pbar.close()
                        x_vec = x_blocks.ravel()
                        return x_vec, residuals

                pbar.update(1)

            pbar.close()

        x_vec = x_blocks.ravel()
        return x_vec, residuals

# ------------------------------------------------------------------------------
# Optional: streaming global solvers using the reader API
# ------------------------------------------------------------------------------

def fit_global_kaczmarz(
    reader,
    *,
    epochs: int = 1,
    pixels_per_aperture: int = 256,
    comp_weights: np.ndarray | None = None,   # (nComp,)
    row_order: str = "c-major",
    rng: np.random.Generator | None = None,
    solver: KaczmarzSolver | None = None,
) -> np.ndarray:
    """
    **Global true-prior Kaczmarz (full-aperture streaming).**

    Solves for a single global coefficient vector using randomized Kaczmarz while
    **incorporating per-component priors** during the updates (i.e., column scaling).
    Each aperture is streamed in full; per-iteration updates use either all pixels or a
    random subset.

    Parameters
    ----------
    reader : HyperCubeReader
        Must provide: `nSpat`, `nComp`, `nPop`, `nLSpec`,
        and `iter_apertures(indices)` yielding `(i, A_T, y)` where `A_T` is `(N, L)`.
    epochs : int, default=1
        Number of passes over the set of apertures.
    pixels_per_aperture : int, default=256
        Number of random spectral pixels to use per aperture per epoch. If
        `>= nLSpec`, uses all pixels.
    comp_weights : ndarray or None, shape (nComp,), optional
        Per-component positive weights used as a **true prior**. They are expanded to
        per-row weights (`(nComp*nPop,)`) following `row_order` and applied inside
        each Kaczmarz update.
    row_order : {"c-major", "p-major"}, default="c-major"
        Row ordering for the global matrix; controls how component weights expand:
          * `"c-major"`: row = `c*nPop + p` → `w_flat = repeat(w_comp, nPop)`
          * `"p-major"`: row = `p*nComp + c` → `w_flat = tile(w_comp, nPop)`
    rng : numpy.random.Generator or None, optional
        RNG used to shuffle apertures and sample pixels. Default creates a fresh generator.
    solver : KaczmarzSolver or None, optional
        Solver instance (learning rate, etc.). If `None`, uses a default `KaczmarzSolver()`.

    Returns
    -------
    x : ndarray, shape (nComp*nPop,)
        **Physical** global solution vector. If a prior is provided, internally the method
        maintains an unscaled variable :math:`\\tilde{x}` and returns `x = w_flat ⊙ x̃`.

    Notes
    -----
    *True prior*: Each row-update for pixel `ℓ` uses `a_w = w_flat ⊙ a` instead of `a`,
    where `a = A_T[:, ℓ]`. The internal variable `x̃` is updated with respect to `a_w`;
    the physical variable is `x = w_flat ⊙ x̃`. Nonnegativity is enforced on `x` and
    mapped back to `x̃`.

    Examples
    --------
    >>> reader = HyperCubeReader(zarr_path, ReaderCfg(flatten=True))
    >>> solver = KaczmarzSolver(lr=0.25)
    >>> comp_w = np.ones(reader.nComp)  # trivial prior
    >>> x = fit_global_kaczmarz(reader, epochs=1, comp_weights=comp_w, solver=solver)
    """

    solver = solver or KaczmarzSolver()
    C, P, L = reader.nComp, reader.nPop, reader.nLSpec
    N = C * P

    # Expand per-component weights → per-row
    if comp_weights is not None:
        w_comp = np.asarray(comp_weights, dtype=np.float64)
        if w_comp.shape != (C,):
            raise ValueError(f"comp_weights must be shape ({C},), got {w_comp.shape}")
        if row_order == "c-major":
            w_flat = np.repeat(w_comp, P)
        elif row_order == "p-major":
            w_flat = np.tile(w_comp, P)
        else:
            raise ValueError("row_order must be 'c-major' or 'p-major'")
        w_flat = np.maximum(w_flat, 1e-12)
    else:
        w_flat = None

    # Internal variable
    x_tilde = np.zeros(N, dtype=np.float64)
    rng = rng or np.random.default_rng()
    all_spax = np.arange(reader.nSpat, dtype=np.int64)

    for _ in range(epochs):
        rng.shuffle(all_spax)
        for s, A_T, y in tqdm(reader.iter_apertures(all_spax),
            total=reader.nSpat, desc="[Global true-prior] epoch"
        ):
            if pixels_per_aperture >= L:
                pixels = np.arange(L, dtype=np.int64)
            else:
                pixels = rng.integers(0, L, size=pixels_per_aperture,
                    endpoint=False)

            if w_flat is None:
                # vanilla row-Kaczmarz
                for ell in pixels:
                    a = A_T[:, ell]
                    denom = float(a @ a) + 1e-12
                    r = y[ell] - float(a @ x_tilde)
                    x_tilde += solver.lr * (r / denom) * a
                np.maximum(x_tilde, 0.0, out=x_tilde)
            else:
                # true prior: weighted design
                for ell in pixels:
                    a = A_T[:, ell]
                    a_w = w_flat * a
                    denom = float(a_w @ a_w) + 1e-12
                    r = y[ell] - float(a_w @ x_tilde)
                    x_tilde += solver.lr * (r / denom) * a_w
                # project physical x >= 0 and map back
                z = w_flat * x_tilde
                np.maximum(z, 0.0, out=z)
                x_tilde = z / w_flat

    # Physical solution
    return (w_flat * x_tilde) if w_flat is not None else x_tilde

# ------------------------------------------------------------------------------

def fit_global_kaczmarz_tiled(
    reader,
    *,
    epochs: int = 1,
    pixels_per_aperture: int = 256,
    comp_weights: np.ndarray | None = None,   # (nComp,)
    row_order: str = "c-major",
    rng: np.random.Generator | None = None,
    solver: KaczmarzSolver | None = None,
) -> np.ndarray:
    """
    **Global true-prior Kaczmarz (tiled streaming).**

    Memory-bounded variant that iterates each aperture in (C,P)-aligned tiles and
        updates only the corresponding slice of the **internal** variable
        :math:`\\tilde{x}`. A per-component prior is incorporated **during** the
        block updates as column scaling.

    Parameters
    ----------
    reader : HyperCubeReader
        Must provide: `nSpat`, `nComp`, `nPop`, `nLSpec`,
        and `iter_aperture_tiles(i, flatten=True)` yielding
        `((c0,c1,p0,p1), A_tile_T, (r0,r1))` where `A_tile_T` is `(rows, L)`.
    epochs : int, default=1
        Number of passes over the set of apertures.
    pixels_per_aperture : int, default=256
        Number of random spectral pixels to use per aperture per epoch for each
            tile.
        If `>= nLSpec`, uses all pixels.
    comp_weights : ndarray or None, shape (nComp,), optional
        Per-component positive weights used as a **true prior**. Expanded to
            per-row weights and applied inside each block update.
    row_order : {"c-major", "p-major"}, default="c-major"
        Controls how component weights expand to rows (see
            `fit_global_kaczmarz`).
    rng : numpy.random.Generator or None, optional
        RNG used to shuffle apertures and sample pixels. Default creates a fresh
            generator.
    solver : KaczmarzSolver or None, optional
        Solver instance (learning rate, etc.). If `None`, uses a default
            `KaczmarzSolver()`.

    Returns
    -------
    x : ndarray, shape (nComp*nPop,)
        **Physical** global solution vector after incorporating the prior.

    Notes
    -----
    Each tile update calls `KaczmarzSolver.solve_block` with the **tile-local**
        slice of the internal vector `x̃[r0:r1]` and (if a prior is provided) the
        **expanded per-row** weights `w_rows = w_flat[r0:r1]`. Nonnegativity is
        enforced on the physical vector at each step.

    Examples
    --------
    >>> reader = HyperCubeReader(zarr_path, ReaderCfg(flatten=True, max_rows_in_mem=8192))
    >>> solver = KaczmarzSolver(lr=0.25)
    >>> comp_w = np.ones(reader.nComp)  # trivial prior
    >>> x = fit_global_kaczmarz_tiled(reader, epochs=1, comp_weights=comp_w, solver=solver)
    """

    solver = solver or KaczmarzSolver()
    C, P, L = reader.nComp, reader.nPop, reader.nLSpec
    N = C * P

    # Expand per-component weights → per-row (global)
    if comp_weights is not None:
        w_comp = np.asarray(comp_weights, dtype=np.float64)
        if w_comp.shape != (C,):
            raise ValueError(f"comp_weights must be shape ({C},), got {w_comp.shape}")
        if row_order == "c-major":
            w_flat = np.repeat(w_comp, P)
        elif row_order == "p-major":
            w_flat = np.tile(w_comp, P)
        else:
            raise ValueError("row_order must be 'c-major' or 'p-major'")
        w_flat = np.maximum(w_flat, 1e-12)
    else:
        w_flat = None

    x_tilde = np.zeros(N, dtype=np.float64)
    rng = rng or np.random.default_rng()
    all_spax = np.arange(reader.nSpat, dtype=np.int64)

    for _ in range(epochs):
        rng.shuffle(all_spax)
        for s in tqdm(all_spax, total=reader.nSpat, desc="[Global-tiled true-prior] epoch"):
            # Observed spectrum once per aperture
            _, y = reader.read_aperture(s, flatten=True)
            if y is None:
                raise RuntimeError("Reader did not provide /Data; supply observed y.")

            for (c0,c1,p0,p1), A_tile_T, (r0, r1) in reader.iter_aperture_tiles(s, flatten=True):
                # Choose pixel subset
                if pixels_per_aperture >= L:
                    pixels = None
                else:
                    pixels = rng.integers(0, L, size=pixels_per_aperture, endpoint=False)

                # Tile slice of internal variable
                x_slice = x_tilde[r0:r1]

                if w_flat is None:
                    x_new, _ = solver.solve_block(
                        A_tile_T, y, x_slice,
                        pixels=pixels,
                        project_nonneg=True,
                    )
                else:
                    # Per-row prior for THIS tile
                    w_rows = w_flat[r0:r1]
                    # Use solve_block with already-expanded per-row weights
                    x_new, _ = solver.solve_block(
                        A_tile_T, y, x_slice,
                        pixels=pixels,
                        comp_weights=w_rows,  # (rows,)
                        nPop=1,               # indicates we've provided per-row weights
                        project_nonneg=True,
                    )

                x_tilde[r0:r1] = x_new

    # Physical solution
    return (w_flat * x_tilde) if w_flat is not None else x_tilde
